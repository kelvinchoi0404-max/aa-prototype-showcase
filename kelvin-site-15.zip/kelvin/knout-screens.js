(() => {
  'use strict';

  const tabs = [...document.querySelectorAll('[data-kn-tab]')];
  const support = document.querySelector('.kn-support');
  const panels = tabs.map(tab => document.getElementById(tab.getAttribute('aria-controls')));
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const panelAnimations = new Map();
  let current = tabs.findIndex(tab => tab.getAttribute('aria-selected') === 'true');
  let visible = false;
  let hovered = false;
  let timer;

  const schedule = () => {
    clearTimeout(timer);
    if (!support || !visible || hovered || document.hidden || reducedMotion.matches ||
        support.querySelector(':focus-visible') || document.querySelector('.kn-viewer[open]')) return;
    timer = setTimeout(() => selectTab(tabs[(current + 1) % tabs.length]), 4500);
  };

  const selectTab = (tab, focus = false) => {
    const next = tabs.indexOf(tab);
    if (next < 0) return;
    const previous = current;
    current = next;
    panelAnimations.forEach(animation => animation.cancel());
    panelAnimations.clear();
    tabs.forEach((button, index) => {
      const selected = button === tab;
      button.setAttribute('aria-selected', String(selected));
      button.tabIndex = selected ? 0 : -1;
      const panel = panels[index];
      panel.hidden = !selected;
      panel.inert = !selected;
      panel.setAttribute('aria-hidden', String(!selected));
    });
    if (previous !== next && !reducedMotion.matches) {
      const incoming = panels[next];
      const outgoing = panels[previous];
      if (outgoing) {
        outgoing.hidden = false;
        const fadeOut = outgoing.animate([
          {opacity: 1, transform: 'translateX(0)'},
          {opacity: 0, transform: 'translateX(-12px)'}
        ], {duration: 240, easing: 'ease-out', fill: 'both'});
        panelAnimations.set(outgoing, fadeOut);
        fadeOut.finished.then(() => {
          if (current !== previous) outgoing.hidden = true;
          fadeOut.cancel();
          panelAnimations.delete(outgoing);
        }).catch(() => {});
      }
      const fadeIn = incoming.animate([
        {opacity: 0, transform: 'translateX(22px)'},
        {opacity: 1, transform: 'translateX(0)'}
      ], {duration: 600, easing: 'cubic-bezier(.16,1,.3,1)', fill: 'both'});
      panelAnimations.set(incoming, fadeIn);
      fadeIn.finished.then(() => {
        fadeIn.cancel();
        panelAnimations.delete(incoming);
      }).catch(() => {});
    }
    if (focus) tab.focus();
    schedule();
  };
  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => { if (index !== current) selectTab(tab); });
    tab.addEventListener('pointerenter', event => {
      if (event.pointerType !== 'touch' && index !== current) selectTab(tab);
    });
    tab.addEventListener('focus', () => { if (index !== current) selectTab(tab); });
    tab.addEventListener('keydown', event => {
      let next;
      if (event.key === 'ArrowDown' || event.key === 'ArrowRight') next = (index + 1) % tabs.length;
      if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') next = (index - 1 + tabs.length) % tabs.length;
      if (event.key === 'Home') next = 0;
      if (event.key === 'End') next = tabs.length - 1;
      if (next !== undefined) {
        event.preventDefault();
        selectTab(tabs[next], true);
      }
    });
  });
  if (support && tabs.length) {
    support.addEventListener('pointerenter', event => {
      if (event.pointerType !== 'touch') { hovered = true; schedule(); }
    });
    support.addEventListener('pointerleave', () => { hovered = false; schedule(); });
    support.addEventListener('focusin', schedule);
    support.addEventListener('focusout', () => queueMicrotask(schedule));
    document.addEventListener('visibilitychange', schedule);
    reducedMotion.addEventListener('change', () => { selectTab(tabs[current]); });
    new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (visible) panels.forEach(panel => panel.querySelectorAll('img').forEach(image => { image.loading = 'eager'; }));
      schedule();
    }, {threshold: .15}).observe(support);
    selectTab(tabs[current < 0 ? 0 : current]);
  }

  const viewer = document.querySelector('.kn-viewer');
  if (!viewer) return;
  const stage = viewer.querySelector('.kn-viewer-stage');
  const title = viewer.querySelector('#kn-viewer-title');
  const close = viewer.querySelector('.kn-viewer-close');
  let opener;
  let previousOverflow = '';
  let catalogPromise;

  const getCatalog = () => {
    if (!catalogPromise) {
      catalogPromise = fetch('/assets/portfolio/knout-latest/screens.json')
        .then(response => {
          if (!response.ok) throw new Error('Unable to load interface catalog');
          return response.json();
        }).catch(error => {
          catalogPromise = null;
          throw error;
        });
    }
    return catalogPromise;
  };

  const createPhone = screen => {
    const phone = document.createElement('div');
    phone.className = 'kn-phone';
    phone.dataset.screen = screen.id;
    phone.dataset.long = String(screen.long);
    const crop = screen.crop;
    const fit = screen.long ? 100 : Math.min(100, (956 / 440 * .884) / (crop.height / crop.width) * 100);
    phone.style.setProperty('--sw', crop.width);
    phone.style.setProperty('--sh', crop.height);
    phone.style.setProperty('--sy', crop.y);
    phone.style.setProperty('--capture-width', `${fit}%`);
    if (screen.id === '78' || screen.id === '79') phone.style.setProperty('--screen-bg', '#746f64');
    const display = document.createElement('div');
    display.className = 'kn-display';
    const scroll = document.createElement('div');
    scroll.className = 'kn-scroll';
    if (screen.long) {
      scroll.tabIndex = 0;
      scroll.setAttribute('aria-label', `${screen.title}，向下捲動查看完整長頁`);
    }
    const capture = document.createElement('div');
    capture.className = 'kn-capture';
    const image = document.createElement('img');
    image.src = `/${screen.display_file}`;
    image.alt = `KnoutCounter Android 實際介面：${screen.title}`;
    image.width = screen.width;
    image.height = screen.height;
    capture.append(image);
    scroll.append(capture);
    display.append(scroll);
    phone.append(display);
    return phone;
  };

  document.querySelectorAll('[data-screen-open]').forEach(button => {
    button.addEventListener('click', async () => {
      button.disabled = true;
      try {
        const screens = await getCatalog();
        const screen = screens.find(item => item.id === button.dataset.screenOpen);
        if (!screen) throw new Error('Interface not found');
        opener = button;
        stage.replaceChildren(createPhone(screen));
        title.textContent = screen.title;
        previousOverflow = document.body.style.overflow;
        document.body.style.overflow = 'hidden';
        viewer.showModal();
        schedule();
        viewer.scrollTop = 0;
        close.focus();
      } catch {
        const existingImage = button.closest('figure')?.querySelector('img');
        if (existingImage) window.open(existingImage.src, '_blank', 'noopener');
      } finally {
        button.disabled = false;
      }
    });
  });
  close.addEventListener('click', () => viewer.close());
  viewer.addEventListener('close', () => {
    document.body.style.overflow = previousOverflow;
    stage.replaceChildren();
    opener?.focus({ preventScroll: true });
    schedule();
  });
})();
