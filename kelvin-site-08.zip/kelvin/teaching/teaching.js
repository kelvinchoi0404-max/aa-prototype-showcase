(() => {
  'use strict';
  const screens = [...document.querySelectorAll('[data-teaching-screen]')];
  const viewer = document.querySelector('.teaching-viewer');
  if (!screens.length || !viewer) return;
  const image = viewer.querySelector('.teaching-viewer-image img');
  const title = viewer.querySelector('#teaching-viewer-title');
  const count = viewer.querySelector('[data-teaching-count]');
  const close = viewer.querySelector('.teaching-viewer-close');
  const zoom = viewer.querySelector('[data-teaching-zoom]');
  const imageContainer = viewer.querySelector('.teaching-viewer-image');
  let current = 0;
  let trigger;
  let previousOverflow = '';
  function setZoom(enlarged) {
    viewer.classList.toggle('is-zoomed', enlarged);
    zoom.setAttribute('aria-pressed', String(enlarged));
    zoom.textContent = enlarged ? '適合畫面' : '放大細節';
    zoom.setAttribute('aria-label', enlarged ? '將完整介面縮放至適合畫面' : '放大介面細節，以原尺寸檢視');
    image.style.width = enlarged ? `${image.naturalWidth || 1280}px` : '';
    imageContainer.tabIndex = enlarged ? 0 : -1;
    imageContainer.scrollLeft = 0;
    imageContainer.scrollTop = 0;
  }
  function display(index) {
    setZoom(false);
    current = (index + screens.length) % screens.length;
    const screen = screens[current];
    const source = screen.querySelector('img');
    image.src = source.currentSrc || source.src;
    image.alt = source.alt;
    title.textContent = screen.dataset.screenTitle;
    count.textContent = `${String(current + 1).padStart(2, '0')} / ${String(screens.length).padStart(2, '0')}`;
  }
  screens.forEach((screen, index) => screen.addEventListener('click', () => {
    trigger = screen;
    display(index);
    previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    viewer.showModal();
    close.focus();
  }));
  close.addEventListener('click', () => viewer.close());
  zoom.addEventListener('click', () => setZoom(!viewer.classList.contains('is-zoomed')));
  viewer.querySelector('[data-teaching-prev]').addEventListener('click', () => display(current - 1));
  viewer.querySelector('[data-teaching-next]').addEventListener('click', () => display(current + 1));
  viewer.addEventListener('keydown', event => {
    if (viewer.classList.contains('is-zoomed') && event.target === imageContainer) return;
    if (event.key === 'ArrowRight') { event.preventDefault(); display(current + 1); }
    if (event.key === 'ArrowLeft') { event.preventDefault(); display(current - 1); }
  });
  viewer.addEventListener('close', () => {
    document.body.style.overflow = previousOverflow;
    trigger?.focus({ preventScroll: true });
  });
})();
