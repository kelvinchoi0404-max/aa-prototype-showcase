(() => {
  "use strict";

  function init() {
    const menuToggle = document.querySelector(".menu-toggle");
    const mobileMenu = document.getElementById("mobile-menu");
    const menuOverlay = document.querySelector(".menu-overlay");

    if (menuToggle && mobileMenu && menuOverlay) {
      let menuOpen = false;

      function closeMenu(restoreFocus = true) {
        const wasOpen = menuOpen;
        menuOpen = false;
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Open menu");
        mobileMenu.hidden = true;
        menuOverlay.hidden = true;
        document.body.classList.remove("menu-open");

        if (wasOpen && restoreFocus && menuToggle.getClientRects().length) {
          menuToggle.focus({ preventScroll: true });
        }
      }

      function menuFocusables() {
        return [
          menuToggle,
          ...mobileMenu.querySelectorAll(
            'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])',
          ),
        ].filter((element) => element.getClientRects().length > 0);
      }

      function openMenu() {
        if (window.innerWidth > 720) return;

        menuOpen = true;
        menuToggle.setAttribute("aria-expanded", "true");
        menuToggle.setAttribute("aria-label", "Close menu");
        mobileMenu.hidden = false;
        menuOverlay.hidden = false;
        document.body.classList.add("menu-open");
        const firstLink = menuFocusables()[1];
        if (firstLink) firstLink.focus({ preventScroll: true });
      }

      menuToggle.addEventListener("click", () => {
        if (menuOpen) closeMenu();
        else openMenu();
      });

      menuOverlay.addEventListener("click", () => closeMenu());
      mobileMenu.addEventListener("click", (event) => {
        if (event.target.closest("a")) closeMenu();
      });

      document.addEventListener("keydown", (event) => {
        if (!menuOpen) return;

        if (event.key === "Escape") {
          event.preventDefault();
          closeMenu();
          return;
        }

        if (event.key !== "Tab") return;

        const focusables = menuFocusables();
        const currentIndex = focusables.indexOf(document.activeElement);
        const direction = event.shiftKey ? -1 : 1;
        const nextIndex = currentIndex < 0
          ? (event.shiftKey ? focusables.length - 1 : 0)
          : (currentIndex + direction + focusables.length) % focusables.length;

        event.preventDefault();
        focusables[nextIndex]?.focus();
      });

      window.addEventListener("resize", () => {
        if (window.innerWidth > 720) closeMenu(false);
      });

      closeMenu(false);
    }

    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    const counters = Array.from(document.querySelectorAll(".stat .count")).map(
      (element, index) => ({
        element,
        index,
        target: Number(element.dataset.target),
        suffix: element.dataset.suffix || "",
        decimals: Number(element.dataset.decimals || 0),
        started: false,
        timer: null,
        frame: null,
      }),
    );
    let observer;

    function render(counter, value) {
      counter.element.textContent = value.toFixed(counter.decimals) + counter.suffix;
    }

    function finish(counter) {
      window.clearTimeout(counter.timer);
      window.cancelAnimationFrame(counter.frame);
      counter.started = true;
      render(counter, counter.target);
    }

    function start(counter) {
      if (counter.started) return;
      counter.started = true;

      if (reducedMotion.matches) {
        finish(counter);
        return;
      }

      counter.timer = window.setTimeout(() => {
        const duration = 1500 + counter.index * 80;
        let startTime;

        function tick(timestamp) {
          if (startTime === undefined) startTime = timestamp;
          const progress = Math.min((timestamp - startTime) / duration, 1);
          const eased = 1 - Math.pow(1 - progress, 3);
          render(counter, counter.target * eased);

          if (progress < 1) counter.frame = window.requestAnimationFrame(tick);
          else finish(counter);
        }

        counter.frame = window.requestAnimationFrame(tick);
      }, 480 + counter.index * 90);
    }

    if (reducedMotion.matches) {
      counters.forEach(finish);
    } else {
      counters.forEach((counter) => render(counter, 0));

      if ("IntersectionObserver" in window) {
        const counterByElement = new Map(
          counters.map((counter) => [counter.element.closest(".stat"), counter]),
        );

        observer = new IntersectionObserver(
          (entries) => {
            entries.forEach((entry) => {
              if (!entry.isIntersecting || entry.intersectionRatio < 0.25) return;
              const counter = counterByElement.get(entry.target);
              if (counter) start(counter);
              observer.unobserve(entry.target);
            });
          },
          { threshold: 0.25 },
        );

        counterByElement.forEach((counter, element) => observer.observe(element));
      } else {
        counters.forEach(start);
      }
    }

    reducedMotion.addEventListener("change", (event) => {
      if (!event.matches) return;
      observer?.disconnect();
      counters.forEach(finish);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();

window.REFERENCE_ASSETS = {"https://framerusercontent.com/assets/1K3W8DizY3v4emK8Mb08YHxTbs.woff2":"/assets/reference/1K3W8DizY3v4emK8Mb08YHxTbs.woff2","https://framerusercontent.com/assets/4RAEQdEOrcnDkhHiiCbJOw92Lk.woff2":"/assets/reference/4RAEQdEOrcnDkhHiiCbJOw92Lk.woff2","https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2":"/assets/reference/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2","https://framerusercontent.com/assets/996sR9SfSDuYELz8oHhDOcErkY.woff2":"/assets/reference/996sR9SfSDuYELz8oHhDOcErkY.woff2","https://framerusercontent.com/assets/A0Wcc7NgXMjUuFdquHDrIZpzZw0.woff2":"/assets/reference/A0Wcc7NgXMjUuFdquHDrIZpzZw0.woff2","https://framerusercontent.com/assets/DpPBYI0sL4fYLgAkX8KXOPVt7c.woff2":"/assets/reference/DpPBYI0sL4fYLgAkX8KXOPVt7c.woff2","https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2":"/assets/reference/EOr0mi4hNtlgWNn9if640EZzXCo.woff2","https://framerusercontent.com/assets/GIryZETIX4IFypco5pYZONKhJIo.woff2":"/assets/reference/GIryZETIX4IFypco5pYZONKhJIo.woff2","https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2":"/assets/reference/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2","https://framerusercontent.com/assets/JAur4lGGSGRGyrFi59JSIKqVgU.woff2":"/assets/reference/JAur4lGGSGRGyrFi59JSIKqVgU.woff2","https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2":"/assets/reference/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2","https://framerusercontent.com/assets/Mput0MSwESKlJ6TMz9MPDXhgrk.woff2":"/assets/reference/Mput0MSwESKlJ6TMz9MPDXhgrk.woff2","https://framerusercontent.com/assets/NeGmSOXrPBfEFIy5YZeHq17LEDA.woff2":"/assets/reference/NeGmSOXrPBfEFIy5YZeHq17LEDA.woff2","https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2":"/assets/reference/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2","https://framerusercontent.com/assets/PONfPc6h4EPYwJliXQBmjVx7QxI.woff2":"/assets/reference/PONfPc6h4EPYwJliXQBmjVx7QxI.woff2","https://framerusercontent.com/assets/UrzZBOy7RyJEWAZGduzOeHiHuY.woff2":"/assets/reference/UrzZBOy7RyJEWAZGduzOeHiHuY.woff2","https://framerusercontent.com/assets/VgYFWiwsAC5OYxAycRXXvhze58.woff2":"/assets/reference/VgYFWiwsAC5OYxAycRXXvhze58.woff2","https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2":"/assets/reference/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2","https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2":"/assets/reference/b6Y37FthZeALduNqHicBT6FutY.woff2","https://framerusercontent.com/assets/cRJyLNuTJR5jbyKzGi33wU9cqIQ.woff2":"/assets/reference/cRJyLNuTJR5jbyKzGi33wU9cqIQ.woff2","https://framerusercontent.com/assets/ftN1HpyPVJEoEb4q36SOrNdLXU.woff2":"/assets/reference/ftN1HpyPVJEoEb4q36SOrNdLXU.woff2","https://framerusercontent.com/assets/hyOgCu0Xnghbimh0pE8QTvtt2AU.woff2":"/assets/reference/hyOgCu0Xnghbimh0pE8QTvtt2AU.woff2","https://framerusercontent.com/assets/lEJLP4R0yuCaMCjSXYHtJw72M.woff2":"/assets/reference/lEJLP4R0yuCaMCjSXYHtJw72M.woff2","https://framerusercontent.com/assets/oYaAX5himiTPYuN8vLWnqBbfD2s.woff2":"/assets/reference/oYaAX5himiTPYuN8vLWnqBbfD2s.woff2","https://framerusercontent.com/assets/syRNPWzAMIrcJ3wIlPIP43KjQs.woff2":"/assets/reference/syRNPWzAMIrcJ3wIlPIP43KjQs.woff2","https://framerusercontent.com/assets/tUSCtfYVM1I1IchuyCwz9gDdQ.woff2":"/assets/reference/tUSCtfYVM1I1IchuyCwz9gDdQ.woff2","https://framerusercontent.com/assets/yDtI2UI8XcEg1W2je9XPN3Noo.woff2":"/assets/reference/yDtI2UI8XcEg1W2je9XPN3Noo.woff2","https://framerusercontent.com/assets/zsnJN7Z1wdzUvepJniD3rbvJIyU.woff2":"/assets/reference/zsnJN7Z1wdzUvepJniD3rbvJIyU.woff2","https://framerusercontent.com/images/1zmQmyhWHK91PjzxGCgoA5tI.jpg":"/assets/reference/1zmQmyhWHK91PjzxGCgoA5tI.jpg","https://framerusercontent.com/images/5KeGZQeFfgU0rvABui656QeziDo.jpg":"/assets/reference/5KeGZQeFfgU0rvABui656QeziDo.jpg","https://framerusercontent.com/images/70Xca6rv2k0iWcFWx3dU5wPTCg.jpg":"/assets/reference/70Xca6rv2k0iWcFWx3dU5wPTCg.jpg","https://framerusercontent.com/images/7skl4fkrDr6ORdFqQdH3FNRZH9k.jpg":"/assets/reference/7skl4fkrDr6ORdFqQdH3FNRZH9k.jpg","https://framerusercontent.com/images/A3ajD2cGVXccaVdIGWx3f0TzV7Y.jpg":"/assets/reference/A3ajD2cGVXccaVdIGWx3f0TzV7Y.jpg","https://framerusercontent.com/images/DkPWVYN8XegaC8mQqHPvL2CBOCk.jpg":"/assets/reference/DkPWVYN8XegaC8mQqHPvL2CBOCk.jpg","https://framerusercontent.com/images/E1CD3VEbcD7R9OCzukgKPstfN44.jpg":"/assets/reference/E1CD3VEbcD7R9OCzukgKPstfN44.jpg","https://framerusercontent.com/images/E8llj4Im88hDdLJ4FKTMh0fz0c.jpg":"/assets/reference/E8llj4Im88hDdLJ4FKTMh0fz0c.jpg","https://framerusercontent.com/images/FZfzWflO4rzYAyXqdIZhqhuhcI.jpg":"/assets/reference/FZfzWflO4rzYAyXqdIZhqhuhcI.jpg","https://framerusercontent.com/images/Fi5BIIRgNqAPQzDBAn1LKMiXuCs.jpg":"/assets/reference/Fi5BIIRgNqAPQzDBAn1LKMiXuCs.jpg","https://framerusercontent.com/images/HTar5qN1H5cvxg5N5cUCSbHNY4A.jpg":"/assets/reference/HTar5qN1H5cvxg5N5cUCSbHNY4A.jpg","https://framerusercontent.com/images/Id8qOsOjoUl5KbOJP5tCopZRWTE.jpg":"/assets/reference/Id8qOsOjoUl5KbOJP5tCopZRWTE.jpg","https://framerusercontent.com/images/NPIoLOgiIsEC9sUCyLxDKc61gFY.jpg":"/assets/reference/NPIoLOgiIsEC9sUCyLxDKc61gFY.jpg","https://framerusercontent.com/images/O9XCnGObjSJA0GOhhq04bXEjw.jpg":"/assets/reference/O9XCnGObjSJA0GOhhq04bXEjw.jpg","https://framerusercontent.com/images/OP3uj8MuCCmrkFhiV0EPiM773w.jpg":"/assets/reference/OP3uj8MuCCmrkFhiV0EPiM773w.jpg","https://framerusercontent.com/images/PAkG5uLHRx68e8TgHcI4x1Ck70.jpg":"/assets/reference/PAkG5uLHRx68e8TgHcI4x1Ck70.jpg","https://framerusercontent.com/images/QMKUixb6UohUNZ2upRDOo3Qtk.jpg":"/assets/reference/QMKUixb6UohUNZ2upRDOo3Qtk.jpg","https://framerusercontent.com/images/THmcZw699qDxRVdf51SmmpiCn0.jpg":"/assets/reference/THmcZw699qDxRVdf51SmmpiCn0.jpg","https://framerusercontent.com/images/WWj8H5KRMu22WzSkmish7xMRr2o.jpg":"/assets/reference/WWj8H5KRMu22WzSkmish7xMRr2o.jpg","https://framerusercontent.com/images/b6gZUNOVX9w7Yscgpmxf4Pi9AK8.jpg":"/assets/reference/b6gZUNOVX9w7Yscgpmxf4Pi9AK8.jpg","https://framerusercontent.com/images/fimhsNqtNZSNBKB90HsnlAgmAE.jpg":"/assets/reference/fimhsNqtNZSNBKB90HsnlAgmAE.jpg","https://framerusercontent.com/images/gDYuS1Kc5AOhBtVUEmxuBHG8HAk.jpg":"/assets/reference/gDYuS1Kc5AOhBtVUEmxuBHG8HAk.jpg","https://framerusercontent.com/images/hQeXXZXlsisXEf7FJEb4kiEZb2s.jpg":"/assets/reference/hQeXXZXlsisXEf7FJEb4kiEZb2s.jpg","https://framerusercontent.com/images/jxijStnK2BUmW1RM5oYWNEdRGUQ.jpg":"/assets/reference/jxijStnK2BUmW1RM5oYWNEdRGUQ.jpg","https://framerusercontent.com/images/k1dnQ7sje8BJ9K3Zh7aX5L6rxc.jpg":"/assets/reference/k1dnQ7sje8BJ9K3Zh7aX5L6rxc.jpg","https://framerusercontent.com/images/kKLVVl5QAGePMW425api4yW41Y.jpg":"/assets/reference/kKLVVl5QAGePMW425api4yW41Y.jpg","https://framerusercontent.com/images/mjdYppLQervPoog5HD0xD2rI5M.jpg":"/assets/reference/mjdYppLQervPoog5HD0xD2rI5M.jpg","https://framerusercontent.com/images/mlwU0O1OgN64gXIefwenoIf7ko.jpg":"/assets/reference/mlwU0O1OgN64gXIefwenoIf7ko.jpg","https://framerusercontent.com/images/moTAv4UqG5TTMS99hfZkkmpc.jpg":"/assets/reference/moTAv4UqG5TTMS99hfZkkmpc.jpg","https://framerusercontent.com/images/qzojly2Hi9IidxktBS6veOI93M.jpg":"/assets/reference/qzojly2Hi9IidxktBS6veOI93M.jpg","https://framerusercontent.com/images/sADGnQ1BJsohi2b0jvG6DCj2kU8.jpg":"/assets/reference/sADGnQ1BJsohi2b0jvG6DCj2kU8.jpg","https://framerusercontent.com/images/v4Z9HwGLgTM0VNdWDI3pUQlnZA.jpg":"/assets/reference/v4Z9HwGLgTM0VNdWDI3pUQlnZA.jpg","https://framerusercontent.com/images/yJdMcQ4J42nJvHYDcTtWH2NC0.jpg":"/assets/reference/yJdMcQ4J42nJvHYDcTtWH2NC0.jpg","https://framerusercontent.com/third-party-assets/fontshare/wf/3U7D2WJULAFN5UCDE2DSKFPDTJNUSRPY/XTZGHUDFURQVBRVTOPX7XHP5YBIQJL2U/FVNNCZHGTHUOM3RCJDOO45QMBIJISVEG.woff2":"/assets/reference/FVNNCZHGTHUOM3RCJDOO45QMBIJISVEG.woff2","https://framerusercontent.com/third-party-assets/fontshare/wf/57U2OK2BISA74Z4RT4CRD5GR4O3PNVPY/K4TDAPUNBYK24HOCNW4JIOTEXSAE2BEF/GV5XODI2YD2DJA5RVTMJOSDHYESL7IYT.woff2":"/assets/reference/GV5XODI2YD2DJA5RVTMJOSDHYESL7IYT.woff2","https://framerusercontent.com/third-party-assets/fontshare/wf/AJVGEOXGB2ALQKAZEK2LDOLCVBCMCOIT/LDEP4R7SNNABDEG433DCQGM2A7YCBHLU/OWABOLGBAKFVLPZ756IYS6EKYKU54K3I.woff2":"/assets/reference/OWABOLGBAKFVLPZ756IYS6EKYKU54K3I.woff2","https://framerusercontent.com/third-party-assets/fontshare/wf/DG3FNZZAXTT6HZWYCQT3SK2X2XDKA6XH/KWXXWQ4T72VNT2BQDELHDOCDISYUBIWM/XMNYCZFXUH3EYMLHCQEDXUTZTCNGZHL5.woff2":"/assets/reference/XMNYCZFXUH3EYMLHCQEDXUTZTCNGZHL5.woff2","https://framerusercontent.com/third-party-assets/fontshare/wf/TX2N2Q6ZO2LBO34H72H5RVJTBQFGU4GV/ZICVNTLTT4V7CCIJPWNY363N6LIP2AET/OUUAK2X2MEGEKC6ULA4CFSBY4PE5EGPV.woff2":"/assets/reference/OUUAK2X2MEGEKC6ULA4CFSBY4PE5EGPV.woff2","https://framerusercontent.com/third-party-assets/fontshare/wf/UABF25CCX23LBLOOMOCUSPFEXYUNKOIQ/NGF5IU7BZUA2FUOVWECHGUFSHNEIX4YK/QDINYT7WQXBD2IDFQGGJ74DWIUFHOOZD.woff2":"/assets/reference/QDINYT7WQXBD2IDFQGGJ74DWIUFHOOZD.woff2","https://framerusercontent.com/third-party-assets/fontshare/wf/UCVXDNZGT5A6V6IG4FWRDHOLGWGQQV4M/TH4CJJ2LCTVPQVYTQSEXOUCHE4FDIZON/LPCI46BISLFAK3QOD4U4IAMRBITTSFAP.woff2":"/assets/reference/LPCI46BISLFAK3QOD4U4IAMRBITTSFAP.woff2","https://framerusercontent.com/third-party-assets/fontshare/wf/XU3SIPSTILVUEE57N33LI57RHN4LESB2/NYZOFSLOXP2NLUPPPC3HSJFYFAYFD5WF/MRD5H7VGACV27ZK3D773YPWKUWZ5UTUZ.woff2":"/assets/reference/MRD5H7VGACV27ZK3D773YPWKUWZ5UTUZ.woff2","https://framerusercontent.com/third-party-assets/fontshare/wf/XYQDC7JAGGEKCBFTJWJFLWLJYO67C7XN/RVU7P55XKD46CPRWMPRMGQG2XS5IZ3EH/RJHIBK2KTTRF4HQSD33LZE5P3HZAYGJ2.woff2":"/assets/reference/RJHIBK2KTTRF4HQSD33LZE5P3HZAYGJ2.woff2","https://framerusercontent.com/third-party-assets/fontshare/wf/ZLH2B3SFZRQ3US4ZUYG2367OYUMTVTGK/RSOPFK2EORTGBCOBZRY42GDLXFFB4IQW/JZ35FM4UJSKC7X2PM65RH75Q5KLE552S.woff2":"/assets/reference/JZ35FM4UJSKC7X2PM65RH75Q5KLE552S.woff2","https://framerusercontent.com/images/0XtMqCEFuA13O8NOvsgmBKqZJI.jpg":"/assets/reference/0XtMqCEFuA13O8NOvsgmBKqZJI.jpg","https://framerusercontent.com/images/2P1kcKfCoxKYWGlwmpzBwvlT4.jpg":"/assets/reference/2P1kcKfCoxKYWGlwmpzBwvlT4.jpg","https://framerusercontent.com/images/2gQh0WU1GxtQecZwf8T4LgYyng.jpg":"/assets/reference/2gQh0WU1GxtQecZwf8T4LgYyng.jpg","https://framerusercontent.com/images/37oMeWmyj1aSWajU1IJkphdmrdw.jpg":"/assets/reference/37oMeWmyj1aSWajU1IJkphdmrdw.jpg","https://framerusercontent.com/images/5aluZOpTMsLlgf7x2xGoU6Wr5U.jpg":"/assets/reference/5aluZOpTMsLlgf7x2xGoU6Wr5U.jpg","https://framerusercontent.com/images/9ckkfQcdKd4xoGlu9tBrQhpS7eY.jpg":"/assets/reference/9ckkfQcdKd4xoGlu9tBrQhpS7eY.jpg","https://framerusercontent.com/images/CHkiFyUl7eGFX66YKl9dhbNxAE.jpg":"/assets/reference/CHkiFyUl7eGFX66YKl9dhbNxAE.jpg","https://framerusercontent.com/images/CKqLSLkVwBCfwkE8l7d6Zo069o.jpg":"/assets/reference/CKqLSLkVwBCfwkE8l7d6Zo069o.jpg","https://framerusercontent.com/images/DjZWayBT6Y4OKIJ0a37Uy8D04.jpg":"/assets/reference/DjZWayBT6Y4OKIJ0a37Uy8D04.jpg","https://framerusercontent.com/images/GcGIRrxmilFJgMwMQLs1Yyq9l3Y.jpg":"/assets/reference/GcGIRrxmilFJgMwMQLs1Yyq9l3Y.jpg","https://framerusercontent.com/images/IZzGJrsQlFgPkRTvIQhjwC0xxcQ.jpg":"/assets/reference/IZzGJrsQlFgPkRTvIQhjwC0xxcQ.jpg","https://framerusercontent.com/images/IdHSAWZ5IIErcNQ5gGSAiIk6zDY.jpg":"/assets/reference/IdHSAWZ5IIErcNQ5gGSAiIk6zDY.jpg","https://framerusercontent.com/images/IwxGL5JeDLbgbHtE0Kyc3kRydQ.jpg":"/assets/reference/IwxGL5JeDLbgbHtE0Kyc3kRydQ.jpg","https://framerusercontent.com/images/QhCV0cfOPVr8zjE7wfe4g6ZSrU.jpg":"/assets/reference/QhCV0cfOPVr8zjE7wfe4g6ZSrU.jpg","https://framerusercontent.com/images/QlN8gS8mfS01Xge4LwEp4jNVXQ.jpg":"/assets/reference/QlN8gS8mfS01Xge4LwEp4jNVXQ.jpg","https://framerusercontent.com/images/Xqf0UqXUDKSh3vbF62Ux6N9NG3k.jpg":"/assets/reference/Xqf0UqXUDKSh3vbF62Ux6N9NG3k.jpg","https://framerusercontent.com/images/YUFB8cfdyqLxBBKFf38zVVY6Buk.jpg":"/assets/reference/YUFB8cfdyqLxBBKFf38zVVY6Buk.jpg","https://framerusercontent.com/images/ZK669r5F84Pcg0KVeRiqmUzEik.jpg":"/assets/reference/ZK669r5F84Pcg0KVeRiqmUzEik.jpg","https://framerusercontent.com/images/aNEJTJzFBKOYYlsqWMcSi4mcd4.jpg":"/assets/reference/aNEJTJzFBKOYYlsqWMcSi4mcd4.jpg","https://framerusercontent.com/images/ba9ZMmlIcSVJjHA1PQi8zsqvhk.jpg":"/assets/reference/ba9ZMmlIcSVJjHA1PQi8zsqvhk.jpg","https://framerusercontent.com/images/brgbKvEn8fS1PcsA2D4oqMI86c.jpg":"/assets/reference/brgbKvEn8fS1PcsA2D4oqMI86c.jpg","https://framerusercontent.com/images/bt17Yizj0jal98fytStuHgzDAk0.jpg":"/assets/reference/bt17Yizj0jal98fytStuHgzDAk0.jpg","https://framerusercontent.com/images/di1DRGBNo87zjY7PuLuenMswI.jpg":"/assets/reference/di1DRGBNo87zjY7PuLuenMswI.jpg","https://framerusercontent.com/images/hzaykHrduBWrNuwQWMlj35C2s.jpg":"/assets/reference/hzaykHrduBWrNuwQWMlj35C2s.jpg","https://framerusercontent.com/images/iN0zy3SRvNX7vK2btET4fdp6tZY.jpg":"/assets/reference/iN0zy3SRvNX7vK2btET4fdp6tZY.jpg","https://framerusercontent.com/images/iXkEu3dDVOgXjeEeJvv44Gg.jpg":"/assets/reference/iXkEu3dDVOgXjeEeJvv44Gg.jpg","https://framerusercontent.com/images/mQBOeullmOgujeA5O7NHQSmObU.jpg":"/assets/reference/mQBOeullmOgujeA5O7NHQSmObU.jpg","https://framerusercontent.com/images/omqoihQq1d441lEVtYeuH0jFW1E.jpg":"/assets/reference/omqoihQq1d441lEVtYeuH0jFW1E.jpg","https://framerusercontent.com/images/tLIngsBJNS6TtXArbQbEqcb9wmc.jpg":"/assets/reference/tLIngsBJNS6TtXArbQbEqcb9wmc.jpg","https://framerusercontent.com/images/wKhvhDj9n9TjuFao8ddemWEbU6U.jpg":"/assets/reference/wKhvhDj9n9TjuFao8ddemWEbU6U.jpg","https://framerusercontent.com/images/wgssOAgUzDWhOAaI0Vy3HrOV4.jpg":"/assets/reference/wgssOAgUzDWhOAaI0Vy3HrOV4.jpg","https://framerusercontent.com/images/xC4J0Oj9AgyE7ijKK5LLfutgY.jpg":"/assets/reference/xC4J0Oj9AgyE7ijKK5LLfutgY.jpg","https://framerusercontent.com/images/yfI1OUwfI2qIl960LCYhd2Jfok.jpg":"/assets/reference/yfI1OUwfI2qIl960LCYhd2Jfok.jpg","https://framerusercontent.com/images/zqFyLLHYwYJLs9AXEwhlc26iNI.jpg":"/assets/reference/zqFyLLHYwYJLs9AXEwhlc26iNI.jpg"};

/* Static, framework-free interactions for the reference sections. */
(() => {
  'use strict';

  const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));
  const services = [
  [
    "產品與界面",
    "gDYuS1Kc5AOhBtVUEmxuBHG8HAk.jpg",
    "需求梳理, 使用流程, UI 設計, 互動原型, 體驗調整",
    "從使用者的需要出發，把功能整理成清楚、順手的界面。"
  ],
  [
    "網站與應用",
    "QMKUixb6UohUNZ2upRDOo3Qtk.jpg",
    "個人與品牌網站, Web 應用, 微信小程序, Android 應用, 界面實作",
    "把設計接到真正可操作的產品上，持續打磨使用細節。"
  ],
  [
    "AI 工具與流程",
    "7skl4fkrDr6ORdFqQdH3FNRZH9k.jpg",
    "需求拆解, AI 工具整合, 工作流程, 快速驗證, 內容整理",
    "從具體任務選擇工具，用小步實作確認它是否真的有幫助。"
  ],
  [
    "教學與內容",
    "/assets/courseware/course-home.jpg",
    "生化班 AI 課件, 課件介面設計, 圖文與章節編排, 分步互動圖解, 自測與解說",
    "生化班 AI 課件：從概念圖解，到可操作的學習介面。"
  ],
  [
    "攝影與影像",
    "/assets/photography/photo-021.webp",
    "光影觀察, 人物與情緒, 影像選輯, 色彩處理, 視覺敘事",
    "留意日常的光與情緒，透過取景和編排留下自己的觀看方式。"
  ],
  [
    "生成式視覺",
    "fimhsNqtNZSNBKB90HsnlAgmAE.jpg",
    "文生圖探索, 視覺方向, 概念試作, 圖像迭代, 內容實驗",
    "以生成工具探索畫面，再回到選擇、調整與表達本身。"
  ]
];
  function initReferenceContent(root = document.querySelector('.reference-site')) {
    if (!root || root.dataset.interactionsReady) return;
    root.dataset.interactionsReady = 'true';
    const $ = (selector, scope = root) => scope.querySelector(selector);
    const $$ = (selector, scope = root) => [...scope.querySelectorAll(selector)];
    const children = element => [...(element?.children || [])].filter(child => child.tagName !== 'STYLE');
    const reducedQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    const reduced = () => reducedQuery.matches;
    const coarse = window.matchMedia('(hover: none)');
    const frameUpdates = [];
    const resizeUpdates = [];
    let framePending = false;
    const requestUpdate = () => {
      if (framePending) return;
      framePending = true;
      requestAnimationFrame(() => {
        framePending = false;
        frameUpdates.forEach(update => update());
      });
    };
    window.addEventListener('scroll', requestUpdate, { passive: true });
    window.addEventListener('resize', () => {
      resizeUpdates.forEach(update => update());
      requestUpdate();
    }, { passive: true });
    reducedQuery.addEventListener('change', requestUpdate);

    // Original SSR markup supplies the layout; these rules support state and focus.
    const style = document.createElement('style');
    style.textContent = `
      .reference-site :is(button,a,[role="button"]):focus-visible{outline:2px solid #ff3b21!important;outline-offset:5px}
      .reference-site .ref-service-panel.is-mobile{display:flex!important;flex-direction:column!important}
      .reference-site .ref-service-panel.is-mobile>.ref-service-nav{position:relative!important;inset:auto!important;order:0;flex-direction:row!important;padding:16px;gap:8px!important;overflow-x:auto;flex-shrink:0;scrollbar-width:none}
      .reference-site .ref-service-panel.is-mobile>.ref-service-nav button{white-space:nowrap;font-size:13px!important;padding:8px 12px!important;transform:none!important}
      .reference-site .ref-service-panel.is-mobile>.ref-service-image{position:relative!important;inset:auto!important;order:1;flex:1;min-height:240px}
      .reference-site .ref-service-panel.is-mobile>.ref-service-title{position:relative!important;inset:auto!important;order:2;max-width:none!important;font-size:36px!important;line-height:1em!important;padding:16px 16px 0;margin:0!important}
      .reference-site .ref-service-panel.is-mobile>.ref-service-title>span{margin-right:.22em!important}
      .reference-site .ref-service-panel.is-mobile>.ref-service-points{position:relative!important;inset:auto!important;order:3;width:auto!important;display:block!important;padding:10px 16px!important;font-size:13px;color:#8a8a8e}
      .reference-site .ref-service-panel.is-mobile>.ref-service-points li{display:inline;font-size:13px!important}
      .reference-site .ref-service-panel.is-mobile>.ref-service-points li+li:before{content:' · '}
      .reference-site .ref-service-panel.is-mobile>.ref-service-note{position:relative!important;inset:auto!important;order:4;max-width:none!important;padding:0 16px 16px}
      .reference-site .ref-service-panel.is-mobile>.ref-service-note span{color:#ff3b21!important}
      .reference-site .ref-service-panel.is-mobile .ref-service-number{right:16px!important;bottom:8px!important;top:auto!important;height:56px!important;z-index:1;pointer-events:none}
      .reference-site .ref-service-panel.is-mobile .ref-service-number span{font-size:56px!important;line-height:56px!important;color:rgba(0,0,0,.18)!important}
      @media(hover:hover){.reference-site [data-framer-cursor="z5f3b7"],.reference-site [data-framer-cursor="z5f3b7"] *{cursor:none!important}}
      @keyframes refServiceWipe{from{clip-path:inset(0 100% 0 0)}to{clip-path:inset(0)}}
      @keyframes refServiceChar{from{opacity:0;filter:blur(14px);transform:translateX(-.25em)}to{opacity:1;filter:blur(0);transform:none}}
      @keyframes refUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
      @keyframes refPrint{from{opacity:0;transform:translateY(-8px);clip-path:inset(0 0 100% 0)}to{opacity:1;transform:none;clip-path:inset(0)}}
      @media(prefers-reduced-motion:reduce){.reference-site *{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
    `;
    root.append(style);

    // A scroll position controls character colour in either direction, rather than
    // a one-shot reveal. Hidden responsive variants are ignored until displayed.
    const fills = $$('div[aria-label]').map(element => {
      const chars = $$(':scope > div[aria-hidden="true"] > span', element);
      if (!chars.length || !chars.some(char => char.style.transition.includes('color'))) return null;
      const inStudio = Boolean(element.closest('#studio'));
      const testimonial = Boolean(element.closest('.framer-hafaof-container'));
      return { element, chars, base: chars[0].style.color, start: inStudio ? 0.9 : 0.85, end: inStudio ? 0.45 : testimonial ? 0.4 : 0.35, previous: -1 };
    }).filter(Boolean);
    frameUpdates.push(() => {
      fills.forEach(fill => {
        if (!fill.element.getClientRects().length) return;
        const bounds = fill.element.getBoundingClientRect();
        const start = innerHeight * fill.start;
        const end = innerHeight * fill.end - bounds.height * 0.5;
        const progress = reduced() ? 1.2 : Math.round(clamp((start - bounds.top) / Math.max(1, start - end)) * 400) / 400;
        if (progress === fill.previous) return;
        fill.previous = progress;
        fill.chars.forEach((char, index) => {
          const on = reduced() || (progress - index / fill.chars.length) * fill.chars.length * 0.12 >= 1;
          char.style.color = on ? '#0b0b0c' : fill.base;
        });
      });
    });

    // Keep the studio photographs gently offset within their own section.
    const studio = $('#studio');
    const parallax = [[$('.framer-1jvsjvx'), 24], [$('.framer-1xfe5mc'), -30]].filter(([element]) => element);
    frameUpdates.push(() => {
      if (!studio || !studio.getClientRects().length) return;
      const bounds = studio.getBoundingClientRect();
      const progress = clamp((innerHeight - bounds.top) / (innerHeight + bounds.height));
      parallax.forEach(([element, distance]) => {
        element.style.transform = reduced() ? 'none' : `translateY(${(progress * 2 - 1) * distance}px)`;
      });
    });

    // Preserve the reference's mechanical digit strips, 50% visibility trigger,
    // 30ms start delay, 1.6s duration and .08s digit stagger.
    const rollingNumbers = $$('div[aria-label]').map(element => {
      const strips = $$(':scope > span[aria-hidden="true"] > span > span', element).filter(strip => strip.children.length >= 10);
      if (!strips.length) return null;
      const digits = (element.getAttribute('aria-label').match(/\d/g) || []).map(Number);
      if (digits.length !== strips.length) return null;
      return { element, strips, digits, finished: false };
    }).filter(Boolean);
    const finishNumber = number => {
      number.finished = true;
      number.strips.forEach((strip, i) => {
        const spins = Math.max(0, Math.floor(strip.children.length / 10) - 1);
        strip.style.transform = `translateY(-${spins * 10 + number.digits[i]}em)`;
      });
    };
    const numberObserver = new IntersectionObserver(entries => entries.forEach(entry => {
      if (!entry.isIntersecting || entry.intersectionRatio < 0.5) return;
      const number = rollingNumbers.find(number => number.element === entry.target);
      if (number) setTimeout(() => finishNumber(number), reduced() ? 0 : 30);
      numberObserver.unobserve(entry.target);
    }), { threshold: 0.5 });
    rollingNumbers.forEach(number => reduced() ? finishNumber(number) : numberObserver.observe(number.element));
    reducedQuery.addEventListener('change', () => { if (reduced()) rollingNumbers.forEach(finishNumber); });

    // The orange View cursor only appears over source project/case targets.
    const cursorTargets = $$('[data-framer-cursor="z5f3b7"]');
    if (cursorTargets.length) {
      const cursor = document.createElement('div');
      cursor.setAttribute('aria-hidden', 'true');
      cursor.style.cssText = 'position:fixed;left:0;top:0;width:96px;height:96px;border-radius:50%;background:#ff3b21;color:#fff;display:grid;place-items:center;font:700 11px/1.3 "Inter",sans-serif;letter-spacing:.06em;text-transform:uppercase;pointer-events:none;z-index:10000;opacity:0;scale:.7;transition:opacity .2s ease,scale .35s cubic-bezier(.16,1,.3,1)';
      cursor.textContent = 'View';
      root.append(cursor);
      cursorTargets.forEach(target => {
        target.addEventListener('pointerenter', event => {
          if (event.pointerType !== 'mouse') return;
          cursor.style.transform = `translate(${event.clientX - 48}px,${event.clientY - 48}px)`;
          cursor.style.opacity = '1'; cursor.style.scale = '1';
        });
        target.addEventListener('pointermove', event => {
          if (event.pointerType === 'mouse') cursor.style.transform = `translate(${event.clientX - 48}px,${event.clientY - 48}px)`;
        });
        target.addEventListener('pointerleave', () => { cursor.style.opacity = '0'; cursor.style.scale = '.7'; });
      });
      window.addEventListener('blur', () => { cursor.style.opacity = '0'; });
    }

    // Non-scroll-linked headings reveal once as their original text group enters.
    const revealGroups = new Map();
    $$('[data-reveal-char]').forEach(char => {
      const group = char.parentElement;
      if (!revealGroups.has(group)) revealGroups.set(group, []);
      revealGroups.get(group).push(char);
      if (!reduced()) Object.assign(char.style, { opacity: '0', transform: 'translateY(40px)', filter: 'blur(10px)' });
    });
    const revealObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        (revealGroups.get(entry.target) || []).forEach((char, index) => {
          if (reduced()) Object.assign(char.style, { opacity: '1', transform: 'none', filter: 'none' });
          else {
            char.animate([{ opacity: 0, transform: 'translateY(40px)', filter: 'blur(10px)' }, { opacity: 1, transform: 'none', filter: 'none' }], { duration: 750, delay: index * 70, easing: 'cubic-bezier(.16,1,.3,1)', fill: 'forwards' });
          }
        });
        revealObserver.unobserve(entry.target);
      });
    }, { threshold: 0.12 });
    revealGroups.forEach((_, group) => revealObserver.observe(group));
    reducedQuery.addEventListener('change', () => {
      if (!reduced()) return;
      root.getAnimations({ subtree: true }).forEach(animation => animation.cancel());
      revealGroups.forEach(chars => chars.forEach(char => {
        char.getAnimations().forEach(animation => animation.cancel());
        Object.assign(char.style, { opacity: '1', transform: 'none', filter: 'none' });
      }));
      $$('video').forEach(video => video.pause());
    });

    // Case-study ticker: original 70px/s with 25% speed while hovered.
    $$('[data-marquee]').forEach(track => {
      const originals = children(track);
      const viewport = track.parentElement;
      let animation;
      let visible = false;
      let hovered = false;
      const rebuild = () => {
        animation?.cancel();
        $$('[data-ticker-clone]', track).forEach(clone => clone.remove());
        const gap = parseFloat(getComputedStyle(track).gap) || 64;
        const distance = originals.reduce((sum, item) => sum + item.getBoundingClientRect().width + gap, 0);
        track.style.transform = `translateX(-${gap}px)`;
        if (!distance || reduced()) return;
        const copies = Math.ceil(viewport.clientWidth / distance) + 1;
        for (let i = 0; i < copies; i++) originals.forEach(item => {
          const clone = item.cloneNode(true);
          clone.dataset.tickerClone = '';
          clone.setAttribute('aria-hidden', 'true');
          clone.removeAttribute('aria-posinset');
          clone.removeAttribute('aria-setsize');
          track.append(clone);
        });
        animation = track.animate([{ transform: `translateX(-${gap}px)` }, { transform: `translateX(-${distance + gap}px)` }], { duration: distance / 70 * 1000, iterations: Infinity, easing: 'linear' });
        animation.playbackRate = hovered ? 0.25 : 1;
        if (!visible) animation.pause();
      };
      viewport.addEventListener('pointerenter', () => { hovered = true; if (animation) animation.playbackRate = 0.25; });
      viewport.addEventListener('pointerleave', () => { hovered = false; if (animation) animation.playbackRate = 1; });
      new IntersectionObserver(entries => {
        visible = entries[0].isIntersecting;
        if (animation && !reduced()) visible ? animation.play() : animation.pause();
      }).observe(viewport);
      new ResizeObserver(rebuild).observe(viewport);
      reducedQuery.addEventListener('change', rebuild);
      document.fonts.ready.then(rebuild);
      rebuild();
    });

    // Scroll chooses a destination; one critically damped spring carries the
    // camera, title and photographs together. It never exposes a matte at rest.
    const reelAssetObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        $$('img', entry.target).forEach(image => {
          image.loading = 'eager';
          image.decode?.().catch(() => {});
        });
        reelAssetObserver.unobserve(entry.target);
      });
    }, { rootMargin: '1000px 0px' });
    const reels = $$('#reel > .ssr-variant > div').map(section => {
      const stage = section.firstElementChild;
      const grid = stage?.firstElementChild;
      const titleLayer = stage?.lastElementChild;
      const title = titleLayer?.querySelector('h2');
      const video = section.querySelector('video');
      if (!stage || !grid || !video) return null;
      const button = video.parentElement.querySelector('button');
      const caption = video.parentElement.lastElementChild;
      const images = $$('img', grid);
      section.dataset.reelSpring = 'true';
      grid.style.willChange = 'transform';
      images.forEach(image => { image.style.transition = 'none'; });
      if (button) button.style.transition = 'none';
      if (titleLayer) titleLayer.style.transition = 'none';
      if (caption && caption !== button) caption.hidden = true;
      reelAssetObserver.observe(section);
      video.muted = true;
      new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting && !reduced()) video.play().catch(() => {});
          else video.pause();
        });
      }).observe(video);
      button?.addEventListener('click', () => { location.href = '/photography/'; });
      return { section, stage, grid, titleLayer, title, video, button, images };
    }).filter(Boolean);
    let reelPosition = reduced() ? 1 : 0;
    let reelVelocity = 0;
    let reelTarget = reelPosition;
    let reelFrame = null;
    let reelLastTime = null;
    let activeReel = null;
    const reelForwardThreshold = 0.22;
    const reelReverseThreshold = 0.07;
    const reelFrequency = 7.8;
    const smoothReel = value => {
      const t = clamp(value);
      return t * t * (3 - 2 * t);
    };

    const paintReel = () => {
      if (!activeReel) return;
      const progress = clamp(reelPosition);
      // Logarithmic zoom keeps the perceived camera speed continuous. An exact
      // spring solution avoids time loss on dropped frames and hard end clamps.
      const scale = Math.exp(Math.log(3) * (1 - progress));
      const titleProgress = smoothReel(progress / 0.66);
      const photoOpacity = 0.35 + 0.65 * smoothReel((progress - 0.04) / 0.84);
      const buttonProgress = smoothReel((progress - 0.78) / 0.2);
      const reel = activeReel;
      reel.grid.style.transform = `translate3d(0,0,0) scale(${scale.toFixed(6)})`;
      reel.images.forEach(image => { image.style.opacity = String(photoOpacity); });
      if (reel.titleLayer) {
        reel.titleLayer.style.opacity = String(1 - titleProgress);
        const hidden = String(titleProgress > 0.98);
        if (reel.titleLayer.getAttribute('aria-hidden') !== hidden) reel.titleLayer.setAttribute('aria-hidden', hidden);
      }
      if (reel.title) reel.title.style.transform = `translate3d(0,${-24 * titleProgress}px,0) scale(${1 - 0.015 * titleProgress})`;
      if (reel.button) {
        reel.button.style.opacity = String(buttonProgress);
        reel.button.style.transform = `scale(${1 / scale})`;
        reel.button.style.pointerEvents = buttonProgress > 0.8 ? 'auto' : 'none';
        reel.button.tabIndex = buttonProgress > 0.8 ? 0 : -1;
      }
      const state = reelFrame !== null ? 'moving' : reelPosition === 1 ? 'expanded' : reelPosition === 0 ? 'immersive' : 'moving';
      if (reel.section.dataset.reelState !== state) reel.section.dataset.reelState = state;
    };
    const settleReel = target => {
      if (reelFrame !== null) cancelAnimationFrame(reelFrame);
      reelFrame = null;
      reelPosition = reelTarget = target;
      reelVelocity = 0;
      reelLastTime = null;
      paintReel();
    };
    const stepReel = timestamp => {
      reelFrame = null;
      if (document.hidden || reduced()) { settleReel(reduced() ? 1 : reelTarget); return; }
      if (reelLastTime === null) reelLastTime = timestamp;
      const dt = Math.max(0, (timestamp - reelLastTime) / 1000);
      reelLastTime = timestamp;
      const displacement = reelPosition - reelTarget;
      const coefficient = reelVelocity + reelFrequency * displacement;
      const decay = Math.exp(-reelFrequency * dt);
      reelPosition = reelTarget + (displacement + coefficient * dt) * decay;
      reelVelocity = (reelVelocity - reelFrequency * coefficient * dt) * decay;
      const atRest = Math.abs(reelTarget - reelPosition) < 0.0005 && Math.abs(reelVelocity) < 0.004;
      if (atRest) { settleReel(reelTarget); return; }
      reelFrame = requestAnimationFrame(stepReel);
      paintReel();
    };
    const animateReelTo = target => {
      reelTarget = target;
      if (reduced()) { settleReel(1); return; }
      if (reelFrame === null && (reelPosition !== reelTarget || Math.abs(reelVelocity) > 0.004)) {
        reelLastTime = null;
        reelFrame = requestAnimationFrame(stepReel);
      }
    };
    frameUpdates.push(() => {
      const active = reels.find(reel => reel.section.getClientRects().length);
      if (!active) return;
      if (activeReel !== active) { activeReel = active; paintReel(); }
      if (reduced()) { settleReel(1); active.video.pause(); return; }
      const bounds = active.section.getBoundingClientRect();
      if (bounds.bottom <= 0) { settleReel(1); return; }
      if (bounds.top >= innerHeight) { settleReel(0); return; }
      const progress = clamp(-bounds.top / Math.max(1, bounds.height - active.stage.clientHeight));
      if (progress >= reelForwardThreshold) animateReelTo(1);
      else if (progress <= reelReverseThreshold) animateReelTo(0);
      // Inside the dead band, keep the previous destination and let it finish.
    });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) settleReel(reduced() ? 1 : reelTarget);
      else requestUpdate();
    });
    reducedQuery.addEventListener('change', () => {
      reels.forEach(reel => {
        if (reduced()) reel.video.pause();
        else if (reel.section.getClientRects().length) {
          const bounds = reel.section.getBoundingClientRect();
          if (bounds.bottom > 0 && bounds.top < innerHeight) reel.video.play().catch(() => {});
        }
      });
      requestUpdate();
    });
    paintReel();

    function initWork() {
      const grid = $('.framer-1gcxkgd-container > div');
      if (!grid) return;
      const cards = $$('a', grid);
      let rows = children(grid);
      let columnCount = 0;
      let active = null;
      function activate(card) {
        active = card;
        rows.forEach(row => {
          row.style.flexGrow = card ? (row.contains(card) ? '1.55' : '0.72') : '1';
          children(row).forEach(item => {
            const selected = item === card;
            item.style.flexGrow = selected ? '2.3' : '1';
            const [img, overlay, label] = children(item);
            if (img) img.style.transform = `scale(${selected ? 1.04 : 1.12})`;
            if (overlay) overlay.style.opacity = selected ? '1' : '0';
            if (label) Object.assign(label.style, { opacity: selected ? '1' : '0', transform: selected ? 'none' : 'translateY(18px)', filter: selected ? 'none' : 'blur(6px)' });
          });
        });
      }
      function arrange() {
        const width = grid.getBoundingClientRect().width;
        const next = width < 560 ? 1 : width < 900 ? 2 : 3;
        if (next === columnCount) return;
        columnCount = next;
        const rowStyle = rows[0]?.style.cssText || 'display:flex;gap:6px;flex-basis:0;min-height:0;transition:flex-grow .8s cubic-bezier(.16,1,.3,1)';
        const fragment = document.createDocumentFragment();
        rows = [];
        cards.forEach((card, index) => {
          if (index % next === 0) {
            const row = document.createElement('div');
            row.style.cssText = rowStyle;
            rows.push(row);
            fragment.append(row);
          }
          rows.at(-1).append(card);
        });
        grid.replaceChildren(fragment);
        activate(active);
      }
      cards.forEach(card => {
        card.addEventListener('pointerenter', () => activate(card));
        card.addEventListener('focus', () => activate(card));
      });
      grid.addEventListener('pointerleave', () => activate(null));
      grid.addEventListener('focusout', event => { if (!grid.contains(event.relatedTarget)) activate(null); });
      new ResizeObserver(arrange).observe(grid);
      arrange();
    }
    initWork();

    function initServices() {
      const nav = $('#services nav[aria-label="Services"]');
      if (!nav) return;
      const panel = nav.parentElement;
      const [image, , points, title, note, number] = children(panel);
      if (!image || !points || !title || !note || !number) return;
      panel.classList.add('ref-service-panel');
      [image, nav, points, title, note, number].forEach((el, index) => el.classList.add(['ref-service-image', 'ref-service-nav', 'ref-service-points', 'ref-service-title', 'ref-service-note', 'ref-service-number'][index]));
      const serviceImages = $$('img', image);
      const teachingPreview = document.createElement('a');
      teachingPreview.className = 'ref-teaching-preview';
      teachingPreview.href = '/teaching/';
      teachingPreview.setAttribute('aria-label', '查看生化 AI 課件的介面與設計案例');
      teachingPreview.hidden = true;
      teachingPreview.innerHTML = '<span class="ref-teaching-kicker">BIOCHEM AI / COURSEWARE</span><img src="/assets/courseware/course-home.jpg" width="1280" height="720" alt="生化 AI 課程首頁與六章導覽" loading="lazy"><img src="/assets/courseware/fuzzy-composition.jpg" width="1280" height="720" alt="模糊推理課件的矩陣與分步圖解" loading="lazy"><span class="ref-teaching-link">查看課件設計 <span aria-hidden="true">↗</span></span>';
      image.append(teachingPreview);
      const buttons = $$('button', nav);
      let current = 0;
      let paused = false;
      const restart = (element, animation) => {
        element.style.animation = 'none';
        void element.offsetWidth;
        element.style.animation = reduced() ? 'none' : animation;
      };
      const sourceFor = filename => {
        if (filename.startsWith('/')) return filename;
        const remote = `https://framerusercontent.com/images/${filename}?width=1000&height=1300`;
        const base = remote.split('?')[0];
        return window.REFERENCE_ASSETS?.[remote] || window.REFERENCE_ASSETS?.[base] || `assets/reference/${filename}`;
      };
      function render(index, animate = true) {
        current = (index + services.length) % services.length;
        const [name, filename, tags, summary] = services[current];
        const images = serviceImages;
        panel.classList.toggle('is-teaching', current === 3);
        teachingPreview.hidden = current !== 3;
        if (images.length >= 2) {
          images[0].src = images[1].src;
          images[0].alt = images[1].alt;
          images[0].style.objectPosition = images[1].style.objectPosition;
          images[0].dataset.servicePhoto = images[1].dataset.servicePhoto || 'false';
          images[0].removeAttribute('srcset');
          images[1].src = sourceFor(filename);
          images[1].removeAttribute('srcset');
          images[1].alt = current === 4 ? "金色穹頂的環形結構與光影細節" : name;
          images[1].style.objectPosition = current === 4 ? "65% 50%" : "center";
          images[1].dataset.servicePhoto = String(current === 4);
          if (animate) restart(images[1], 'refServiceWipe 1s cubic-bezier(.76,0,.24,1) both');
        }
        buttons.forEach((button, i) => {
          const selected = i === current;
          button.setAttribute('aria-pressed', String(selected));
          button.style.color = panel.classList.contains('is-mobile') ? selected ? '#fff' : '#0b0b0c' : selected ? '#ff3b21' : '#0b0b0c';
          button.style.background = panel.classList.contains('is-mobile') ? selected ? '#ff3b21' : 'rgba(0,0,0,.05)' : 'transparent';
          button.style.transform = selected ? 'translateX(6px)' : 'none';
        });
        title.replaceChildren();
        title.setAttribute('aria-label', name);
        let charIndex = 0;
        name.split(' ').forEach(word => {
          const wordSpan = document.createElement('span');
          wordSpan.style.cssText = 'display:inline-block;white-space:nowrap;margin-right:.22em';
          wordSpan.setAttribute('aria-hidden', 'true');
          [...word].forEach(char => {
            const span = document.createElement('span');
            span.textContent = char;
            span.style.display = 'inline-block';
            if (animate && !reduced()) span.style.animation = `refServiceChar .7s cubic-bezier(.16,1,.3,1) ${0.15 + charIndex * 0.035}s both`;
            charIndex++;
            wordSpan.append(span);
          });
          title.append(wordSpan);
        });
        points.replaceChildren();
        tags.split(', ').forEach((tag, i) => {
          const li = document.createElement('li');
          li.textContent = tag;
          li.style.cssText = 'font-size:14px;font-weight:500;letter-spacing:-.01em';
          if (animate && !reduced()) li.style.animation = `refUp .6s cubic-bezier(.16,1,.3,1) ${0.25 + i * 0.06}s both`;
          points.append(li);
        });
        note.lastElementChild.textContent = summary;
        number.lastElementChild.textContent = String(current + 1).padStart(2, '0');
      }
      buttons.forEach((button, index) => {
        button.type = 'button';
        button.addEventListener('click', () => render(index));
        button.addEventListener('pointerenter', () => { if (!coarse.matches && index !== current) render(index); });
        button.addEventListener('focus', () => { if (index !== current) render(index); });
      });
      panel.addEventListener('pointerenter', () => { paused = true; });
      panel.addEventListener('pointerleave', () => { paused = false; });
      panel.addEventListener('focusin', () => { paused = true; });
      panel.addEventListener('focusout', event => { if (!panel.contains(event.relatedTarget)) paused = false; });
      setInterval(() => { if (!paused && !reduced() && !document.hidden) render(current + 1); }, 4500);
      let mobile = null;
      const resize = () => {
        const next = panel.getBoundingClientRect().width < 760;
        if (next === mobile) return;
        mobile = next;
        panel.classList.toggle('is-mobile', mobile);
        (mobile ? image : panel).append(number);
        render(current, false);
      };
      new ResizeObserver(resize).observe(panel);
      resize();
    }
    initServices();

    function initProcess() {
      const grid = $('.framer-20lk1n-container > div');
      if (!grid) return;
      const cards = children(grid);
      const ordered = [...cards].sort((a, b) => parseInt(a.textContent, 10) - parseInt(b.textContent, 10));
      let current = 0;
      let paused = false;
      let visible = false;
      function activate(index) {
        current = index;
        ordered.forEach((card, i) => {
          const selected = i === index;
          card.setAttribute('aria-pressed', String(selected));
          Object.assign(card.style, { background: selected ? '#161618' : '#f1f1f0', color: selected ? '#fff' : '#0b0b0c', transform: selected && !reduced() ? 'translateY(-6px)' : 'none', boxShadow: selected ? '0 30px 40px -24px rgba(0,0,0,.45)' : 'none', zIndex: selected ? '2' : '1' });
          const badge = card.firstElementChild?.firstElementChild;
          if (badge) Object.assign(badge.style, { background: selected ? '#ff3b21' : '#fff', color: selected ? '#fff' : '#0b0b0c' });
          if (card.lastElementChild?.lastElementChild) card.lastElementChild.lastElementChild.style.color = selected ? 'rgba(255,255,255,.6)' : '#8a8a8e';
        });
      }
      ordered.forEach((card, index) => {
        card.tabIndex = 0;
        card.setAttribute('role', 'button');
        card.addEventListener('pointerenter', () => activate(index));
        card.addEventListener('focus', () => activate(index));
        card.addEventListener('click', () => activate(index));
        card.addEventListener('keydown', event => {
          if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); activate(index); }
          if (['ArrowRight', 'ArrowDown', 'ArrowLeft', 'ArrowUp'].includes(event.key)) {
            event.preventDefault();
            const next = (index + (['ArrowLeft', 'ArrowUp'].includes(event.key) ? -1 : 1) + cards.length) % cards.length;
            ordered[next].focus();
          }
        });
      });
      grid.addEventListener('pointerenter', () => { paused = true; });
      grid.addEventListener('pointerleave', () => { paused = false; });
      grid.addEventListener('focusin', () => { paused = true; });
      grid.addEventListener('focusout', event => { if (!grid.contains(event.relatedTarget)) paused = false; });
      new IntersectionObserver(entries => { visible = entries[0].intersectionRatio >= 0.4; }, { threshold: [0, 0.4] }).observe(grid);
      setInterval(() => { if (visible && !paused && !reduced() && !document.hidden) activate((current + 1) % cards.length); }, 2600);
      new ResizeObserver(() => {
        const mobile = grid.getBoundingClientRect().width < 560;
        grid.style.gridTemplateColumns = mobile ? '1fr' : '1fr 1fr';
        grid.style.gridTemplateRows = mobile ? 'repeat(4,auto)' : '1fr 1fr';
        grid.style.height = mobile ? 'auto' : '100%';
        cards.forEach(card => { card.style.minHeight = mobile ? '200px' : '0'; card.style.order = mobile ? String(ordered.indexOf(card)) : ''; });
      }).observe(grid);
      activate(0);
    }
    initProcess();

    requestUpdate();
  }

  window.initReferenceContent = initReferenceContent;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => initReferenceContent(), { once: true });
  else initReferenceContent();
})();

/* Shared static-page navigation and a local-only project brief form. */
(() => {
  function initNavigation() {
    const header = document.querySelector('.reference-nav');
    if (!header) return;
    const toggle = header.querySelector('.reference-menu-toggle');
    const menu = header.querySelector('.reference-navigation');
    const opening = document.querySelector('.page');
    let open = false;
    const content = [...document.querySelectorAll('body > .page, body > .reference-site')];
    const showHeader = () => {
      const visible = !opening || opening.getBoundingClientRect().bottom <= 56;
      header.hidden = !visible;
      if (!visible && open) setOpen(false, false);
    };
    function setOpen(value, restoreFocus = true) {
      open = value;
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
      menu.hidden = !open;
      document.body.classList.toggle('reference-menu-open', open);
      content.forEach(el => { el.inert = open; });
      if (open) menu.querySelector('a').focus({preventScroll:true});
      else if (restoreFocus && !header.hidden) toggle.focus({preventScroll:true});
    }
    toggle.addEventListener('click', () => setOpen(!open));
    menu.addEventListener('click', e => { if (e.target.closest('a')) setOpen(false, false); });
    document.addEventListener('keydown', e => {
      if (!open) return;
      if (e.key === 'Escape') { e.preventDefault(); setOpen(false); }
      if (e.key === 'Tab') {
        const nodes = [toggle, ...menu.querySelectorAll('a[href],button')];
        const i = nodes.indexOf(document.activeElement);
        e.preventDefault();
        nodes[(i + (e.shiftKey ? -1 : 1) + nodes.length) % nodes.length].focus();
      }
    });
    addEventListener('scroll', showHeader, {passive:true});
    showHeader();

    document.querySelectorAll('.reference-site form').forEach(form => {
      const params = new URLSearchParams(location.search);
      const message = form.querySelector('textarea');
      if (message && params.has('brief')) message.value = params.get('brief');
      form.setAttribute('aria-label', 'Project brief');
      form.removeAttribute('action');
      const submit = form.querySelector('button[type="submit"],input[type="submit"]');
      if (submit) {
        if (submit.tagName === 'INPUT') submit.value = 'Download brief';
        else submit.textContent = 'Download brief ↗';
      }
      const status = document.createElement('p');
      status.className = 'reference-form-status';
      status.setAttribute('role','status');
      status.textContent = 'Save your project brief as a text file. Nothing is sent online.';
      form.append(status);
      form.addEventListener('submit', e => {
        e.preventDefault();
        if (!form.reportValidity()) return;
        const lines = ['Project brief — Kelvin Choi', ''];
        for (const [key, value] of new FormData(form)) if (typeof value === 'string' && value.trim()) lines.push(key + ': ' + value.trim(), '');
        const url = URL.createObjectURL(new Blob([lines.join('\n')], {type:'text/plain;charset=utf-8'}));
        const link = document.createElement('a');
        link.href=url; link.download='project-brief.txt'; link.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        status.textContent = 'Your brief has been downloaded. No message has been sent.';
      });
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',initNavigation,{once:true});
  else initNavigation();
})();
