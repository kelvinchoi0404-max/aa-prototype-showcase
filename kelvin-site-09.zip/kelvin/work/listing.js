(() => {
  'use strict';
  const video = document.querySelector('[data-maos-listing-video]');
  if (!video) return;
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let inView = false;
  video.muted = true;
  const sync = () => {
    const allowed = inView && !document.hidden && !reducedMotion.matches;
    if (!allowed) {video.pause(); return;}
    if (video.paused) video.play().catch(() => {});
  };
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(entries => {
      const entry = entries[0];
      inView = entry.isIntersecting && entry.intersectionRatio >= .15;
      sync();
    }, {threshold: [0, .15]}).observe(video);
  }
  document.addEventListener('visibilitychange', sync);
  window.addEventListener('pagehide', () => video.pause());
  window.addEventListener('pageshow', sync);
  reducedMotion.addEventListener('change', sync);
})();
