(() => {
  'use strict';
  const filters = [...document.querySelectorAll('[data-role-filter]')];
  const groups = [...document.querySelectorAll('[data-role-section]')];
  function selectRole(role) {
    if (!['parent', 'teacher'].includes(role)) return;
    filters.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.roleFilter === role)));
    groups.forEach(group => { group.hidden = group.dataset.roleSection !== role; });
  }
  filters.forEach((button, index) => {
    button.addEventListener('click', () => {
      selectRole(button.dataset.roleFilter);
      history.replaceState(null, '', `#${button.dataset.roleFilter}-flow`);
    });
    button.addEventListener('keydown', event => {
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      const nextIndex = event.key === 'Home' ? 0 : event.key === 'End' ? filters.length - 1 : (index + (event.key === 'ArrowRight' ? 1 : -1) + filters.length) % filters.length;
      const next = filters[nextIndex];
      selectRole(next.dataset.roleFilter);
      next.focus();
    });
  });
  selectRole('parent');
  document.querySelectorAll('[data-flow-link]').forEach(link => link.addEventListener('click', event => {
    event.preventDefault();
    selectRole(link.dataset.flowLink);
    const target = document.querySelector(link.getAttribute('href'));
    history.pushState(null, '', link.getAttribute('href'));
    target?.scrollIntoView({block:'start', inline:'center', behavior:matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth'});
    target?.querySelector('button')?.focus({preventScroll:true});
  }));
  // Deep-linked screenshots must remain reachable even when they belong to the other role.
  function revealHash() {
    const target = document.getElementById(location.hash.slice(1));
    const role = target?.closest('[data-role-section]')?.dataset.roleSection;
    if (role) selectRole(role);
  }
  window.addEventListener('hashchange', revealHash);
  revealHash();

  const triggers = [...document.querySelectorAll('[data-open-screen]')];
  if (!triggers.length) return;
  const dialog = document.createElement('dialog');
  dialog.className = 'wk-screen-dialog';
  dialog.setAttribute('aria-label', '悟空哆哆介面檢視');
  dialog.innerHTML = '<header class="wk-viewer-header"><p aria-live="polite"></p><button type="button" class="wk-viewer-close" aria-label="關閉介面檢視">×</button></header><div class="wk-viewer-content"><div class="wk-viewer-image"></div><div class="wk-viewer-footer"><button type="button" data-screen-prev aria-label="上一個介面">←</button><span aria-live="polite"></span><button type="button" data-screen-next aria-label="下一個介面">→</button></div></div>';
  document.body.append(dialog);
  let currentIndex = 0;
  let opener = null;
  let previousOverflow = '';
  function show(index) {
    currentIndex = (index + triggers.length) % triggers.length;
    const trigger = triggers[currentIndex];
    const screen = trigger.querySelector('.wk-screen').cloneNode(true);
    screen.querySelector('img').loading = 'eager';
    dialog.querySelector('.wk-viewer-image').replaceChildren(screen);
    dialog.querySelector('.wk-viewer-header p').textContent = trigger.dataset.title;
    dialog.querySelector('.wk-viewer-footer span').textContent = `${String(currentIndex + 1).padStart(2, '0')} / ${String(triggers.length).padStart(2, '0')}`;
    dialog.scrollTop = 0;
  }
  triggers.forEach((trigger, index) => trigger.addEventListener('click', () => {
    opener = trigger;
    show(index);
    previousOverflow = document.body.style.overflow;
    dialog.showModal();
    document.body.style.overflow = 'hidden';
  }));
  dialog.querySelector('.wk-viewer-close').addEventListener('click', () => dialog.close());
  dialog.querySelector('[data-screen-prev]').addEventListener('click', () => show(currentIndex - 1));
  dialog.querySelector('[data-screen-next]').addEventListener('click', () => show(currentIndex + 1));
  dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
  dialog.addEventListener('keydown', event => {
    if (event.key === 'ArrowLeft') { event.preventDefault(); show(currentIndex - 1); }
    if (event.key === 'ArrowRight') { event.preventDefault(); show(currentIndex + 1); }
  });
  dialog.addEventListener('close', () => {
    document.body.style.overflow = previousOverflow;
    opener?.focus({preventScroll:true});
  });
})();
