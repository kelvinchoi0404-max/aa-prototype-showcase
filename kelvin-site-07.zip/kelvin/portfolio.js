(() => {
  'use strict';
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const menu = document.querySelector('.mobile-menu');
  const menuToggle = document.querySelector('.menu-toggle');
  const overlay = document.querySelector('.menu-overlay');
  const main = document.querySelector('main');
  const footer = document.querySelector('footer');
  let menuOpen = false;
  function setMenu(open, returnFocus = true) {
    if (!menu || !menuToggle || !overlay) return;
    menuOpen = open;
    menu.hidden = !open;
    overlay.hidden = !open;
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.setAttribute('aria-label', open ? '關閉選單' : '開啟選單');
    document.body.classList.toggle('menu-open', open);
    if (main) main.inert = open;
    if (footer) footer.inert = open;
    if (open) menu.querySelector('a')?.focus();
    else if (returnFocus) menuToggle.focus();
  }
  menuToggle?.addEventListener('click', () => setMenu(!menuOpen));
  overlay?.addEventListener('click', () => setMenu(false));
  menu?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => setMenu(false, false)));
  document.addEventListener('keydown', event => {
    if (!menuOpen) return;
    if (event.key === 'Escape') setMenu(false);
    if (event.key === 'Tab') {
      const focusable = [menuToggle, ...menu.querySelectorAll('a')];
      const first = focusable[0], last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {event.preventDefault(); last.focus();}
      else if (!event.shiftKey && document.activeElement === last) {event.preventDefault(); first.focus();}
    }
  });
  window.addEventListener('resize', () => {if (window.innerWidth > 720 && menuOpen) setMenu(false, false);});
  document.querySelectorAll('.site-nav a,.mobile-menu a').forEach(link => {
    if (link.getAttribute('href') === '/' && location.pathname !== '/') return;
    if (link.getAttribute('href') !== '/' && location.pathname.startsWith(link.getAttribute('href'))) link.setAttribute('aria-current', 'page');
  });
  document.querySelectorAll('[data-year]').forEach(node => node.textContent = String(new Date().getFullYear()));

  // Progressively enhance; all content remains visible without JavaScript.
  const reveals = [...document.querySelectorAll('.reveal')];
  if ('IntersectionObserver' in window) {
    document.documentElement.classList.add('motion-ready');
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) {entry.target.classList.add('is-visible'); observer.unobserve(entry.target);}
    }), {threshold: .08, rootMargin: '0px 0px -15px 0px'});
    reveals.forEach(node => observer.observe(node));
  }
  const scenes = [...document.querySelectorAll('[data-scroll-scene]')];
  let frame = 0;
  function paintScroll() {
    frame = 0;
    if (reducedMotion.matches) return;
    scenes.forEach(scene => {
      const box = scene.getBoundingClientRect();
      if (box.bottom < 0 || box.top > innerHeight) return;
      const progress = Math.max(-1, Math.min(1, (innerHeight / 2 - (box.top + box.height / 2)) / (innerHeight / 2 + box.height / 2)));
      scene.style.setProperty('--scene', progress.toFixed(4));
    });
  }
  if (scenes.length) {
    window.addEventListener('scroll', () => {if (!frame) frame = requestAnimationFrame(paintScroll);}, {passive:true});
    window.addEventListener('resize', paintScroll);
    paintScroll();
  }
  const video = document.querySelector('.bg-video');
  const videoToggle = document.querySelector('.video-toggle');
  let pausedByUser = reducedMotion.matches;
  function updateVideoControl() {
    if (!videoToggle || !video) return;
    const paused = video.paused;
    videoToggle.setAttribute('aria-pressed', String(paused));
    videoToggle.setAttribute('aria-label', paused ? '播放背景影片' : '暫停背景影片');
    videoToggle.innerHTML = paused ? '播放影片 <span aria-hidden="true">▷</span>' : '暫停影片 <span aria-hidden="true">Ⅱ</span>';
  }
  videoToggle?.addEventListener('click', () => {
    if (video.paused) {pausedByUser = false; video.play().catch(updateVideoControl);} else {pausedByUser = true; video.pause();}
    updateVideoControl();
  });
  if (video) {
    if (reducedMotion.matches) video.pause();
    video.addEventListener('play', updateVideoControl);
    video.addEventListener('pause', updateVideoControl);
    video.addEventListener('loadeddata', updateVideoControl);
    if ('IntersectionObserver' in window) new IntersectionObserver(entries => {
      entries.forEach(entry => {if (!entry.isIntersecting) video.pause(); else if (!pausedByUser && !reducedMotion.matches) video.play().catch(() => {});});
    }, {threshold:.01}).observe(video);
    updateVideoControl();
  }
  reducedMotion.addEventListener('change', () => {
    if (reducedMotion.matches) {reveals.forEach(el => el.classList.add('is-visible')); scenes.forEach(el => el.style.setProperty('--scene','0')); video?.pause();}
    else paintScroll();
  });

  document.querySelectorAll('[data-copy-email]').forEach(button => button.addEventListener('click', async () => {
    const email = button.dataset.copyEmail || 'kelvinchoi0404@gmail.com';
    const status = document.querySelector('.copy-status');
    try {await navigator.clipboard.writeText(email); if (status) status.textContent = '電郵地址已複製。';}
    catch {if (status) status.textContent = '請選取並複製上方的電郵地址。';}
  }));

  const photoButtons = [...document.querySelectorAll('.photo-open')];
  if (photoButtons.length) {
    const dialog = document.createElement('dialog');
    dialog.className = 'lightbox';
    dialog.setAttribute('aria-label', '攝影作品檢視');
    dialog.innerHTML = '<button class="lightbox-close" aria-label="關閉作品">×</button><div class="lightbox-inner"><img alt=""><p class="lightbox-caption" aria-live="polite"></p></div><div class="lightbox-nav"><button data-photo-prev aria-label="上一張">←</button><button data-photo-next aria-label="下一張">→</button></div>';
    document.body.append(dialog);
    let photoIndex = 0, trigger = null;
    function showPhoto(index) {
      photoIndex = (index + photoButtons.length) % photoButtons.length;
      const selected = photoButtons[photoIndex];
      const sourceImage = selected.querySelector('img');
      const image = dialog.querySelector('img');
      image.src = selected.dataset.full || sourceImage.src;
      image.alt = sourceImage.alt;
      dialog.querySelector('.lightbox-caption').textContent = `${String(photoIndex+1).padStart(2,'0')} / ${String(photoButtons.length).padStart(2,'0')} — ${(selected.dataset.caption || sourceImage.alt).replace(/^\d+\s*—\s*/, '')}`;
    }
    photoButtons.forEach((button,index) => button.addEventListener('click', () => {trigger = button; showPhoto(index); dialog.showModal(); document.body.style.overflow = 'hidden';}));
    dialog.querySelector('.lightbox-close').addEventListener('click', () => dialog.close());
    dialog.querySelector('[data-photo-prev]').addEventListener('click', () => showPhoto(photoIndex-1));
    dialog.querySelector('[data-photo-next]').addEventListener('click', () => showPhoto(photoIndex+1));
    dialog.addEventListener('keydown', e => {if(e.key === 'ArrowRight') showPhoto(photoIndex+1); if(e.key === 'ArrowLeft') showPhoto(photoIndex-1);});
    dialog.addEventListener('close', () => {document.body.style.overflow = ''; trigger?.focus();});
  }
})();
