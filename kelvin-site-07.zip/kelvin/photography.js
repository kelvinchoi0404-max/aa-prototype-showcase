(() => {
  'use strict';
  const collection = document.querySelector('[data-photography-catalog]');
  if (!collection) return;
  const grid = collection.querySelector('.photography-grid');
  const toolbar = collection.querySelector('.photography-toolbar');
  const filters = collection.querySelector('.photography-filters');
  const count = collection.querySelector('.photography-count');
  const status = collection.querySelector('.photography-status');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let photos = [], categories = [], visiblePhotos = [], activeCategory = 'all';
  let viewer, currentIndex = 0, trigger = null, previousOverflow = '', imageRequest = 0;
  let layoutFrame = 0, layoutSignature = '';
  const items = new Map();

  const categoryLabel = id => categories.find(category => category.id === id)?.label || '';
  const readHash = () => {try {return decodeURIComponent(location.hash.slice(1));} catch {return '';}};
  const make = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };

  function layoutGallery() {
    if (layoutFrame) return;
    layoutFrame = requestAnimationFrame(() => {
      layoutFrame = 0;
      const width = grid.clientWidth;
      if (!width) return;
      const mobile = window.innerWidth <= 720;
      const signature = `${activeCategory}:${mobile}:${Math.round(width)}:${visiblePhotos.map(photo => photo.id).join(',')}`;
      if (signature === layoutSignature) return;
      layoutSignature = signature;
      const focused = grid.contains(document.activeElement) ? document.activeElement : null;
      grid.classList.add('is-editorial');
      const fragment = document.createDocumentFragment();
      const gap = mobile ? 12 : 24;
      const ratio = photo => photo.width / photo.height;
      let cursor = 0, rowIndex = 0;
      // Keep the curated sequence intact. Each row shares a common height,
      // with widths derived from the photographs, never from a crop.
      while (cursor < visiblePhotos.length) {
        const remaining = visiblePhotos.length - cursor;
        const firstRatio = ratio(visiblePhotos[cursor]);
        const leading = cursor === 0 && firstRatio >= 1.3;
        const panoramic = mobile ? firstRatio >= 1.9 : rowIndex > 0 && rowIndex % 5 === 0 && firstRatio >= 1.7;
        let length = leading || panoramic ? 1 : Math.min(2, remaining);
        if (!mobile && length > 1 && remaining >= 3) {
          const pairRatio = firstRatio + ratio(visiblePhotos[cursor + 1]);
          const trioRatio = pairRatio + ratio(visiblePhotos[cursor + 2]);
          const targetHeight = Math.min(440, width * .31);
          const pairHeight = (width - gap) / pairRatio;
          const trioHeight = (width - gap * 2) / trioRatio;
          const pairScore = Math.abs(pairHeight - targetHeight);
          const trioScore = Math.abs(trioHeight - targetHeight) + (rowIndex % 3 === 1 ? -35 : 15);
          if (trioScore < pairScore || firstRatio < .85 && ratio(visiblePhotos[cursor + 1]) < .85) length = 3;
        }
        // A portrait should never become a disproportionately tall final page.
        if (!mobile && remaining === length + 1 && ratio(visiblePhotos[cursor + length]) < 1.15) length += 1;
        const row = make('div', 'photography-row');
        row.dataset.layout = length === 1 ? (leading ? 'lead' : 'wide') : length === 2 ? 'pair' : 'sequence';
        if (!mobile && length === 1 && !leading) row.classList.add('photography-row-inset');
        if (length === 1 && firstRatio < 1) row.classList.add('photography-row-portrait');
        visiblePhotos.slice(cursor, cursor + length).forEach(photo => {
          const item = items.get(photo.id);
          item.style.removeProperty('grid-row-end');
          item.style.setProperty('--photo-ratio', ratio(photo).toFixed(6));
          item.hidden = false;
          row.append(item);
        });
        fragment.append(row);
        cursor += length;
        rowIndex += 1;
      }
      const inactive = make('div', 'photography-inactive');
      inactive.hidden = true;
      const visibleIds = new Set(visiblePhotos.map(photo => photo.id));
      items.forEach((item, id) => {if (!visibleIds.has(id)) inactive.append(item);});
      fragment.append(inactive);
      grid.replaceChildren(fragment);
      grid.querySelectorAll('.photography-row .photography-item').forEach(item => {
        const image = item.querySelector('img');
        image.sizes = `${Math.ceil(item.getBoundingClientRect().width)}px`;
      });
      if (focused?.isConnected) focused.focus({preventScroll:true});
    });
  }

  function buildItems() {
    const existing = new Map([...grid.querySelectorAll('[data-photo-id]')].map(item => [item.dataset.photoId, item]));
    const fragment = document.createDocumentFragment();
    photos.forEach(photo => {
      let figure = existing.get(photo.id);
      if (!figure) {
        figure = make('figure', 'photography-item');
        figure.id = photo.id;
        figure.dataset.photoId = photo.id;
        figure.dataset.category = photo.category;
        const link = make('a', 'photography-open');
        link.href = photo.full;
        link.setAttribute('aria-label', `放大查看：${photo.title}`);
        const image = make('img');
        image.src = photo.thumbnail;
        image.alt = photo.alt || photo.title;
        image.width = photo.width;
        image.height = photo.height;
        image.loading = 'lazy';
        image.decoding = 'async';
        link.append(image);
        const caption = make('figcaption');
        caption.append(make('span', '', photo.title), make('span', '', categoryLabel(photo.category)));
        figure.append(link, caption);
      }
      figure.querySelector('.photography-open').addEventListener('click', event => {
        if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
        if (typeof HTMLDialogElement === 'undefined') return;
        event.preventDefault();
        openPhoto(photo.id, event.currentTarget);
      });
      const image = figure.querySelector('img');
      image.alt = photo.alt || photo.title;
      const thumbnailWidth = Math.round(photo.width * 900 / Math.max(photo.width, photo.height));
      const fullWidth = Math.round(photo.width * 2400 / Math.max(photo.width, photo.height));
      image.srcset = `${photo.thumbnail} ${thumbnailWidth}w, ${photo.full} ${fullWidth}w`;
      image.sizes = '(max-width: 720px) 50vw, 40vw';
      items.set(photo.id, figure);
      fragment.append(figure);
    });
    grid.replaceChildren(fragment);
    window.addEventListener('resize', layoutGallery, {passive:true});
    document.fonts?.ready.then(layoutGallery);
    if ('IntersectionObserver' in window && !reducedMotion.matches) {
      const observer = new IntersectionObserver(entries => entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-entering');
        observer.unobserve(entry.target);
      }), {threshold:0.03});
      items.forEach(item => observer.observe(item));
    }
  }

  function chooseCategory(id, updateUrl = false) {
    activeCategory = categories.some(category => category.id === id) ? id : 'all';
    visiblePhotos = activeCategory === 'all' ? photos : photos.filter(photo => photo.category === activeCategory);
    items.forEach((item, photoId) => {item.hidden = !visiblePhotos.some(photo => photo.id === photoId);});
    filters.querySelectorAll('button').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.category === activeCategory)));
    count.textContent = activeCategory === 'all' ? `${photos.length} 張作品` : `${categoryLabel(activeCategory)} · ${visiblePhotos.length} / ${photos.length} 張`;
    grid.setAttribute('aria-label', activeCategory === 'all' ? '全部攝影作品' : `${categoryLabel(activeCategory)}攝影作品`);
    layoutGallery();
    if (updateUrl) history.replaceState(null, '', `${location.pathname}${location.search}${activeCategory === 'all' ? '' : `#${encodeURIComponent(activeCategory)}`}`);
  }

  function buildFilters() {
    filters.replaceChildren();
    [{id:'all',label:'全部'}, ...categories].forEach(category => {
      const total = category.id === 'all' ? photos.length : photos.filter(photo => photo.category === category.id).length;
      if (!total) return;
      const button = make('button', 'photography-filter', category.label);
      button.type = 'button';
      button.dataset.category = category.id;
      button.setAttribute('aria-pressed', 'false');
      button.setAttribute('aria-controls', 'photography-grid');
      button.append(make('span', '', total));
      button.addEventListener('click', () => chooseCategory(category.id, true));
      filters.append(button);
    });
    toolbar.hidden = false;
  }

  function buildViewer() {
    viewer = make('dialog', 'photography-viewer');
    viewer.setAttribute('aria-labelledby', 'photography-viewer-title');
    viewer.innerHTML = '<div class="photography-viewer-top"><p>KELVIN CHOI / PHOTOGRAPHY</p><button class="photography-viewer-close" type="button" aria-label="關閉作品">×</button></div><div class="photography-viewer-frame"><img alt=""><p class="photography-viewer-loading" role="status" hidden></p></div><div class="photography-viewer-bottom"><div><h2 class="photography-viewer-caption" id="photography-viewer-title"></h2><p class="photography-viewer-category"></p><time class="photography-viewer-date" hidden></time></div><p class="photography-viewer-count" aria-live="polite" aria-atomic="true"></p></div><div class="photography-viewer-navigation"><button type="button" data-previous aria-label="上一張作品">←</button><button type="button" data-next aria-label="下一張作品">→</button></div>';
    document.body.append(viewer);
    viewer.querySelector('.photography-viewer-close').addEventListener('click', () => viewer.close());
    viewer.querySelector('[data-previous]').addEventListener('click', () => showPhoto(currentIndex - 1));
    viewer.querySelector('[data-next]').addEventListener('click', () => showPhoto(currentIndex + 1));
    viewer.addEventListener('keydown', event => {
      if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
        event.preventDefault();
        showPhoto(currentIndex + (event.key === 'ArrowRight' ? 1 : -1));
      }
    });
    viewer.addEventListener('close', () => {
      document.body.style.overflow = previousOverflow;
      layoutGallery();
      trigger?.focus({preventScroll:true});
    });
    viewer.querySelector('.photography-viewer-frame').addEventListener('click', event => {
      if (event.target.classList.contains('photography-viewer-frame')) viewer.close();
    });
    let pointerStart = null;
    viewer.querySelector('img').addEventListener('touchstart', event => {
      pointerStart = event.touches.length === 1 ? {x:event.touches[0].clientX,y:event.touches[0].clientY} : null;
    }, {passive:true});
    viewer.querySelector('img').addEventListener('touchend', event => {
      if (!pointerStart || !event.changedTouches.length) return;
      const x = event.changedTouches[0].clientX - pointerStart.x;
      const y = event.changedTouches[0].clientY - pointerStart.y;
      if (Math.abs(x) > 60 && Math.abs(x) > Math.abs(y) * 1.8) showPhoto(currentIndex + (x < 0 ? 1 : -1));
      pointerStart = null;
    }, {passive:true});
  }

  function showPhoto(index) {
    if (!visiblePhotos.length) return;
    currentIndex = (index + visiblePhotos.length) % visiblePhotos.length;
    const photo = visiblePhotos[currentIndex];
    const image = viewer.querySelector('img');
    const loading = viewer.querySelector('.photography-viewer-loading');
    const request = ++imageRequest;
    image.alt = photo.alt || photo.title;
    image.width = photo.width;
    image.height = photo.height;
    image.src = photo.thumbnail;
    loading.hidden = false;
    loading.textContent = '載入完整影像……';
    const full = new Image();
    full.onload = () => {
      if (request !== imageRequest) return;
      image.src = photo.full;
      loading.hidden = true;
    };
    full.onerror = () => {
      if (request !== imageRequest) return;
      loading.textContent = '暫時顯示預覽影像';
    };
    full.src = photo.full;
    viewer.querySelector('.photography-viewer-caption').textContent = photo.title;
    viewer.querySelector('.photography-viewer-category').textContent = categoryLabel(photo.category);
    const date = viewer.querySelector('.photography-viewer-date');
    const hasVerifiedDate = photo.capturedAtSource === 'EXIF DateTimeOriginal' && /^\d{4}-\d{2}-\d{2}$/.test(photo.capturedAt || '');
    date.hidden = !hasVerifiedDate;
    date.textContent = hasVerifiedDate ? `拍攝於 ${photo.capturedAt.replaceAll('-', '.')}` : '';
    if (hasVerifiedDate) date.dateTime = photo.capturedAt;
    else date.removeAttribute('datetime');
    viewer.querySelector('.photography-viewer-count').textContent = `${String(currentIndex + 1).padStart(2,'0')} / ${visiblePhotos.length}`;
    viewer.querySelectorAll('.photography-viewer-navigation button').forEach(button => {button.disabled = visiblePhotos.length < 2;});
  }

  function openPhoto(id, source) {
    const index = visiblePhotos.findIndex(photo => photo.id === id);
    if (index < 0) return;
    trigger = source || items.get(id)?.querySelector('a');
    showPhoto(index);
    if (!viewer.open) {
      previousOverflow = document.body.style.overflow;
      viewer.showModal();
      document.body.style.overflow = 'hidden';
    }
  }

  function followHash() {
    const hash = readHash();
    if (photos.some(photo => photo.id === hash)) {
      chooseCategory('all');
      requestAnimationFrame(() => {
        items.get(hash)?.scrollIntoView({block:'center',behavior:'instant'});
        if (typeof HTMLDialogElement !== 'undefined') openPhoto(hash);
      });
    } else chooseCategory(hash);
  }

  async function init() {
    try {
      const response = await fetch(collection.dataset.photographyCatalog);
      if (!response.ok) throw new Error(`Catalog ${response.status}`);
      const catalog = await response.json();
      if (!Array.isArray(catalog.photos) || !catalog.photos.length || !Array.isArray(catalog.categories)) throw new Error('Empty catalog');
      photos = catalog.photos;
      categories = catalog.categories;
      buildItems();
      buildFilters();
      buildViewer();
      followHash();
      status.hidden = true;
      window.addEventListener('hashchange', followHash);
    } catch (error) {
      status.hidden = false;
      status.replaceChildren(make('p', '', grid.children.length ? '分類暫時未能載入；仍可點選下方照片查看完整畫面。' : '影像暫時未能載入，請稍後再試。'));
      const retry = make('button', '', '重新載入');
      retry.type = 'button';
      retry.addEventListener('click', init, {once:true});
      status.append(retry);
    }
  }
  init();
})();
