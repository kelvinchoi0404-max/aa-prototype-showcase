/* Mailto keeps the inquiry in the visitor's email client. */
(() => {
  'use strict';
  const email = 'kelvinchoi0404@gmail.com';
  const compose = document.getElementById('contact-compose');
  const status = document.querySelector('.contact-action-status');
  const fields = [
    ['需求', document.getElementById('brief-needs')],
    ['現有素材', document.getElementById('brief-materials')],
    ['預期時程', document.getElementById('brief-timing')]
  ];
  const updateMail = () => {
    if (!compose) return;
    const lines = ['Kelvin 你好，', '', '想和你聊聊一個合作想法：', ''];
    fields.forEach(([label, field]) => {
      const value = field?.value.trim();
      if (value) lines.push(label + '：', value, '');
    });
    compose.href = 'mailto:' + email + '?subject=' + encodeURIComponent('合作洽談') + '&body=' + encodeURIComponent(lines.join('\n'));
  };
  fields.forEach(([,field]) => field?.addEventListener('input',updateMail));
  updateMail();
  document.querySelector('[data-copy-email]')?.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(email);
      status.textContent = '已複製電郵地址。';
    } catch {
      const field = document.createElement('textarea');
      field.value = email;
      field.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.append(field);
      field.select();
      const copied = document.execCommand('copy');
      field.remove();
      status.textContent = copied ? '已複製電郵地址。' : '可直接選取上方電郵地址複製。';
    }
  });
})();
