(() => {
  'use strict';

  const sectionSelector = '.reference-site #studio, .reference-site #work, .reference-site #services, .reference-site #deliverables, .reference-site #reel, .reference-site #cases, .reference-site #process, .reference-site #contact, .kelvin-footer';
  let header;
  let bar;
  let sections = [];
  let scheduled = false;
  let resizeObserver;

  // Read section surfaces only. Photographs and video frames do not change
  // the navigation theme as they move beneath the fixed bar.
  function backgroundTone(section) {
    if (section.id === 'reel' || section.classList.contains('page')) return 'dark';
    for (let node = section; node && node !== document.documentElement; node = node.parentElement) {
      const color = getComputedStyle(node).backgroundColor;
      const parts = color.match(/[\d.]+/g)?.map(Number);
      if (!parts || parts.length < 3 || (parts.length > 3 && parts[3] < .5)) continue;
      const luminance = .2126 * parts[0] + .7152 * parts[1] + .0722 * parts[2];
      return luminance < 128 ? 'dark' : 'light';
    }
    return 'light';
  }

  function update() {
    scheduled = false;
    if (!header?.isConnected || !bar) return;
    const rect = bar.getBoundingClientRect();
    const probe = rect.height ? rect.bottom + 1 : 57;
    const active = sections.find(section => {
      const bounds = section.getBoundingClientRect();
      return bounds.width > 0 && bounds.top <= probe && bounds.bottom > probe;
    });
    const tone = active ? backgroundTone(active) : 'light';
    if (header.dataset.headerTone !== tone) header.dataset.headerTone = tone;
  }

  function schedule() {
    if (!scheduled) {
      scheduled = true;
      requestAnimationFrame(update);
    }
  }

  function refreshSections() {
    sections = [...document.querySelectorAll(`.page, ${sectionSelector}`)];
    resizeObserver?.disconnect();
    if (resizeObserver) sections.forEach(section => resizeObserver.observe(section));
    schedule();
  }

  function bind() {
    header = document.querySelector('.reference-nav');
    bar = header?.querySelector('.reference-nav-bar');
    if (!header || !bar) return false;
    if ('ResizeObserver' in window) resizeObserver = new ResizeObserver(schedule);
    refreshSections();
    addEventListener('scroll', schedule, { passive: true });
    addEventListener('resize', refreshSections, { passive: true });
    addEventListener('pageshow', refreshSections);
    addEventListener('load', refreshSections, { once: true });
    window.visualViewport?.addEventListener('resize', schedule, { passive: true });
    document.fonts?.ready.then(schedule);
    // Main-page content can be initialized after this deferred script.
    const site = document.querySelector('.reference-site');
    if (site) {
      new MutationObserver(records => {
        if (records.some(record => [...record.addedNodes, ...record.removedNodes].some(node => node.nodeType === 1 && (node.matches?.(sectionSelector) || node.querySelector?.(sectionSelector))))) refreshSections();
      }).observe(site, { childList: true, subtree: true });
    }
    update();
    return true;
  }

  function start() {
    if (bind()) return;
    const observer = new MutationObserver(() => {
      if (bind()) observer.disconnect();
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
  else start();
})();
