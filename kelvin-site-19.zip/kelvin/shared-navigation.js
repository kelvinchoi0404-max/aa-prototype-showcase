(() => {
  'use strict';

  const header = document.querySelector('.reference-nav[data-navigation-controller]');
  if (!header || header.dataset.sharedBound) return;
  header.dataset.sharedBound = 'true';
  const toggle = header.querySelector('.reference-menu-toggle');
  const menu = header.querySelector('.reference-navigation');
  const legacyController = header.dataset.navigationController === 'main';
  const backdrop = document.createElement('div');
  backdrop.className = 'shared-nav-backdrop';
  backdrop.setAttribute('aria-hidden', 'true');
  header.after(backdrop);

  let open = false;
  let inertState = new Map();
  function syncBackground(value) {
    if (value) {
      inertState = new Map();
      [...document.body.children].forEach(node => {
        if (node === header || node === backdrop || ['SCRIPT', 'STYLE', 'LINK'].includes(node.tagName)) return;
        // Contact keeps the controller in main.js, which already owns these.
        if (legacyController && node.matches('.page,.reference-site')) return;
        inertState.set(node, node.inert);
        node.inert = true;
      });
    } else {
      inertState.forEach((previous, node) => { if (node.isConnected) node.inert = previous; });
      inertState.clear();
    }
  }
  function setOpen(value, restoreFocus = true) {
    if (open === value) return;
    open = value;
    menu.hidden = !open;
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? '關閉導覽' : '開啟導覽');
    document.body.classList.toggle('reference-menu-open', open);
    syncBackground(open);
    if (open) menu.querySelector('a')?.focus({ preventScroll: true });
    else if (restoreFocus) toggle.focus({ preventScroll: true });
  }

  if (legacyController) {
    // Observe, rather than bind the existing contact controller a second time.
    new MutationObserver(() => {
      const expanded = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-label', expanded ? '關閉導覽' : '開啟導覽');
      if (open !== expanded) {
        open = expanded;
        syncBackground(open);
      }
    }).observe(toggle, { attributes: true, attributeFilter: ['aria-expanded'] });
    backdrop.addEventListener('click', () => { if (open) toggle.click(); });
    header.addEventListener('click', event => {
      if (event.target.closest('a[href]') && toggle.getAttribute('aria-expanded') === 'true') toggle.click();
    });
  } else {
    toggle.addEventListener('click', () => setOpen(!open));
    backdrop.addEventListener('click', () => setOpen(false));
    header.addEventListener('click', event => { if (event.target.closest('a[href]')) setOpen(false, false); });
    document.addEventListener('keydown', event => {
      if (!open) return;
      if (event.key === 'Escape') {
        event.preventDefault();
        setOpen(false);
      }
      if (event.key === 'Tab') {
        const nodes = [...header.querySelectorAll('a[href],button:not([disabled])')].filter(node => node.getClientRects().length);
        const first = nodes[0], last = nodes[nodes.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    });
  }

  function surfaceTone(node) {
    for (; node && node !== document.documentElement; node = node.parentElement) {
      const rgb = getComputedStyle(node).backgroundColor.match(/[\d.]+/g)?.map(Number);
      if (!rgb || rgb.length < 3 || (rgb.length > 3 && rgb[3] < .5)) continue;
      return .2126 * rgb[0] + .7152 * rgb[1] + .0722 * rgb[2] < 128 ? 'dark' : 'light';
    }
    return 'dark';
  }
  let scheduled = false;
  function updateTheme() {
    scheduled = false;
    const bar = header.querySelector('.reference-nav-bar').getBoundingClientRect();
    const probe = bar.bottom + 1;
    const regions = [...document.querySelectorAll('.contact-profile'), ...document.querySelectorAll('body > main > section, body > main > div, body > main > figure, body > main > nav, body > main > a.next-project, #contact-intro, body > footer, .kelvin-footer')];
    const active = regions.find(region => {
      const rect = region.getBoundingClientRect();
      return rect.width > innerWidth * .65 && rect.top <= probe && rect.bottom > probe;
    });
    const fallback = document.querySelector('main') || document.body;
    const tone = surfaceTone(active || fallback);
    if (header.dataset.headerTone !== tone) header.dataset.headerTone = tone;
  }
  function scheduleTheme() {
    if (!scheduled) {
      scheduled = true;
      requestAnimationFrame(updateTheme);
    }
  }
  addEventListener('scroll', scheduleTheme, { passive: true });
  addEventListener('resize', scheduleTheme, { passive: true });
  addEventListener('pageshow', scheduleTheme);
  addEventListener('load', scheduleTheme, { once: true });
  window.visualViewport?.addEventListener('resize', scheduleTheme, { passive: true });
  document.fonts?.ready.then(scheduleTheme);
  if ('ResizeObserver' in window) {
    const observer = new ResizeObserver(scheduleTheme);
    const main = document.querySelector('main');
    if (main) observer.observe(main);
  }
  updateTheme();
})();
