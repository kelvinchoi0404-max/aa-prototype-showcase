(() => {
  'use strict';

  function initHomeWorkWall() {
    const section = document.querySelector('.reference-site #work');
    const wrapper = section?.querySelector('.framer-1gcxkgd-container');
    const grid = wrapper?.querySelector('[data-work-grid]');
    if (!grid || wrapper.dataset.homeWorkWall) return;
    const cards = [...grid.querySelectorAll('a')];
    if (cards.length !== 6) return;

    const pictures = {
      wukongStudent: {src: '/assets/portfolio/wukong-dodo/WechatIMG3561.jpg', width: 842, height: 1786, alt: '悟空哆哆家長與學生端：尋找合適的老師'},
      wukongTeacher: {src: '/assets/portfolio/wukong-dodo/WechatIMG3595.jpg', width: 854, height: 1752, alt: '悟空哆哆教師端：導師工作台'},
      knoutHome: {src: '/assets/portfolio/knout-latest/home.webp', width: 1140, height: 2616, alt: 'KnoutCounter Android 訓練首頁'},
      knoutLibrary: {src: '/assets/portfolio/knout-latest/exercise-library.webp', width: 1140, height: 2616, alt: 'KnoutCounter Android 動作資料庫'},
      course: {src: '/assets/courseware/course-home-hd.jpg', width: 3840, height: 2160, alt: '生化 AI 課件：課程首頁與六章導覽'},
      shadow: {src: '/assets/photography/photo-067.webp', width: 2400, height: 1425, alt: '階梯上的影子：格紋牆上的光斑、人物影子與斜向扶手'},
      aiDrift: {src: '/assets/ai-visuals/drifting-light.webp', width: 1343, height: 2400, alt: '米白衣袖與長髮飄動的懸浮女子，周圍環繞青綠光影與蝴蝶。'},
      aiCoast: {src: '/assets/ai-visuals/coastal-wanderer.webp', width: 1024, height: 1024, alt: '身穿米白長袍的劍客立在海岸草坡上，衣袍隨風揚起。'},
      aiHarbour: {src: '/assets/ai-visuals/red-sails-02.webp', width: 960, height: 1200, alt: '紅帆船穿過青藍色海港，金色煙火照亮夜空。'},
    };
    const works = [
      {title: '悟空哆哆', href: '/work/wukong/', name: 'wukong', ratio: 1.1, phones: ['3561', '3595'], images: [pictures.wukongStudent, pictures.wukongTeacher]},
      {title: 'MAOS', href: '/work/maos/', name: 'maos', ratio: 1920 / 1080, video: true},
      {title: 'KnoutCounter', href: '/work/knoutcounter/', name: 'knout', ratio: 1.1, phones: ['kn-home', 'kn-library'], images: [pictures.knoutHome, pictures.knoutLibrary]},
      {title: '生化 AI 課件', href: '/teaching/', name: 'teaching', images: [pictures.course]},
      {title: 'AI 視覺系列', href: '/visuals/', name: 'ai', ratio: 1.2, montage: true, images: [pictures.aiDrift, pictures.aiCoast, pictures.aiHarbour]},
      {title: '攝影作品', href: '/photography/#photo-067', name: 'photo', images: [pictures.shadow]},
    ];
    const videos = [];

    works.forEach((work, index) => {
      // Keep the original anchors, rows, overlay and label nodes: main.js's
      // initWork already owns their listeners, responsive layout and states.
      const card = cards[index];
      const [oldMedia, overlay, label] = [...card.children].filter(child => child.tagName !== 'STYLE');
      if (!oldMedia || !overlay || !label) return;
      const ratio = work.ratio || work.images.reduce((total, picture) => total + picture.width / picture.height, 0);
      card.classList.add('hww-card', `hww-${work.name}`);
      card.style.setProperty('--hww-ratio', String(ratio));
      card.dataset.workRatio = String(ratio);
      card.setAttribute('aria-label', `查看${work.title}`);
      card.href = work.href;

      const art = document.createElement('div');
      art.className = 'hww-art';
      // Keep the original motion timing. Native-ratio media starts uncropped
      // and gently enlarges with the card on hover.
      art.style.transform = 'scale(1)';
      art.style.transition = oldMedia.style.transition || 'transform 1.1s cubic-bezier(.16,1,.3,1)';
      const pack = document.createElement('div');
      pack.className = 'hww-image-pack';
      if (work.phones) pack.classList.add('hww-phone-pack');

      if (work.video) {
        const video = document.createElement('video');
        video.muted = true;
        video.defaultMuted = true;
        video.loop = true;
        video.playsInline = true;
        video.setAttribute('muted', '');
        video.setAttribute('playsinline', '');
        video.preload = 'metadata';
        video.width = 1920;
        video.height = 1080;
        video.poster = '/assets/portfolio/maos/landing-poster.webp?v=20261025-2';
        video.setAttribute('aria-label', 'MAOS 網站首頁與滾動展示');
        const source = document.createElement('source');
        source.src = '/assets/portfolio/maos/landing-scroll.mp4?v=20261025-2';
        source.type = 'video/mp4';
        video.append(source);
        pack.append(video);
        videos.push({video, inView: false});
      } else {
        work.images.forEach((picture, pictureIndex) => {
          const image = document.createElement('img');
          image.src = picture.src;
          image.width = picture.width;
          image.height = picture.height;
          image.alt = picture.alt;
          image.loading = 'lazy';
          image.decoding = 'async';
          image.style.setProperty('--hww-image-ratio', String(picture.width / picture.height));
          if (work.name === 'photo') {
            image.srcset = '/assets/photography/photo-067-thumb.webp 900w, /assets/photography/photo-067.webp 2400w';
            image.sizes = '(max-width:560px) 100vw, (max-width:900px) 75vw, 60vw';
          }
          if (work.phones) {
            const phone = document.createElement('span');
            phone.className = 'wk-screen';
            phone.dataset.screen = work.phones[pictureIndex];
            const display = document.createElement('span');
            display.className = 'wk-display';
            const capture = document.createElement('span');
            capture.className = 'wk-capture';
            capture.append(image);
            display.append(capture);
            phone.append(display);
            pack.append(phone);
          } else if (work.montage) {
            const tile = document.createElement('span');
            tile.className = 'hww-ai-tile';
            tile.append(image);
            pack.append(tile);
          } else pack.append(image);
        });
      }
      art.append(pack);
      oldMedia.replaceWith(art);
      const title = document.createElement('span');
      title.className = 'work-type';
      title.textContent = work.title;
      label.replaceChildren(title);
    });
    wrapper.dataset.homeWorkWall = 'original-interaction';
    grid.dispatchEvent(new Event('workwallready'));
    const lead = [...section.querySelectorAll('p')].find(paragraph => paragraph.textContent.includes('項目成果、生成式影像與視覺實驗'));
    if (lead) lead.textContent = '產品、網站、互動課件、生成式影像與攝影選作。';

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const sync = state => {
      if (!state.inView || document.hidden || reducedMotion.matches) {
        state.video.pause();
        return;
      }
      if (state.video.paused) state.video.play().catch(() => {});
    };
    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          const state = videos.find(item => item.video === entry.target);
          if (!state) return;
          state.inView = entry.isIntersecting && entry.intersectionRatio >= .15;
          sync(state);
        });
      }, {threshold: [0, .15]});
      videos.forEach(state => observer.observe(state.video));
    }
    document.addEventListener('visibilitychange', () => videos.forEach(sync));
    window.addEventListener('pagehide', () => videos.forEach(state => state.video.pause()));
    window.addEventListener('pageshow', () => videos.forEach(sync));
    reducedMotion.addEventListener('change', () => videos.forEach(sync));
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initHomeWorkWall, {once: true});
  else initHomeWorkWall();
})();
