(() => {
  'use strict';
  const root = document.querySelector('.maos-page');
  if (!root) return;
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const mediaStates = [...root.querySelectorAll('[data-maos-video]')].map(video => {
    const state = {video, inView: false};
    video.muted = true;
    state.pause = () => video.pause();
    state.sync = () => {
      const allowed = state.inView && !document.hidden && !root.classList.contains('maos-image-opened') && !reducedMotion.matches;
      if (!allowed) {state.pause(); return;}
      if (video.paused) video.play().catch(() => {});
    };
    return state;
  });
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        const state = mediaStates.find(item => item.video === entry.target);
        state.inView = entry.isIntersecting && entry.intersectionRatio >= .15;
        state.sync();
      });
    }, {threshold: [0, .15]});
    mediaStates.forEach(state => observer.observe(state.video));
  }
  document.addEventListener('visibilitychange', () => mediaStates.forEach(state => state.sync()));
  window.addEventListener('pagehide', () => mediaStates.forEach(state => state.pause()));
  window.addEventListener('pageshow', () => mediaStates.forEach(state => state.sync()));
  reducedMotion.addEventListener('change', () => mediaStates.forEach(state => state.sync()));

  const dialog = root.querySelector('.maos-lightbox');
  const images = [...root.querySelectorAll('[data-maos-image]')];
  if (!dialog || !images.length) return;
  const enlarged = dialog.querySelector('img');
  const caption = dialog.querySelector('.maos-lightbox-caption');
  const content = dialog.querySelector('.maos-lightbox-content');
  const zoomButton = dialog.querySelector('[data-maos-zoom]');
  let current = 0;
  let trigger = null;
  const setZoom = enabled => {
    dialog.classList.toggle('is-zoomed', enabled);
    zoomButton.setAttribute('aria-pressed', String(enabled));
    zoomButton.setAttribute('aria-label', enabled ? '縮小以顯示完整介面' : '以原尺寸查看介面細節');
    zoomButton.textContent = enabled ? '完整畫面' : '放大細節';
    content.scrollLeft = 0;
    content.scrollTop = 0;
  };
  zoomButton.addEventListener('click', () => setZoom(!dialog.classList.contains('is-zoomed')));
  const show = index => {
    setZoom(false);
    current = (index + images.length) % images.length;
    const selected = images[current];
    const original = selected.querySelector('img');
    enlarged.src = original.currentSrc || original.src;
    enlarged.alt = original.alt;
    caption.textContent = `${String(current + 1).padStart(2, '0')} / ${String(images.length).padStart(2, '0')} · ${selected.dataset.caption || original.alt}`;
  };
  images.forEach((button, index) => button.addEventListener('click', () => {
    trigger = button;
    show(index);
    mediaStates.forEach(state => state.pause());
    dialog.showModal();
    root.classList.add('maos-image-opened');
  }));
  dialog.querySelector('[data-maos-close]').addEventListener('click', () => dialog.close());
  dialog.querySelector('[data-maos-previous]').addEventListener('click', () => show(current - 1));
  dialog.querySelector('[data-maos-next]').addEventListener('click', () => show(current + 1));
  dialog.addEventListener('keydown', event => {
    if (event.key === 'ArrowLeft') {event.preventDefault(); show(current - 1);}
    if (event.key === 'ArrowRight') {event.preventDefault(); show(current + 1);}
  });
  dialog.addEventListener('click', event => {
    if (event.target === dialog || event.target.classList.contains('maos-lightbox-content')) dialog.close();
  });
  dialog.addEventListener('close', () => {
    setZoom(false);
    root.classList.remove('maos-image-opened');
    trigger?.focus({preventScroll: true});
    mediaStates.forEach(state => state.sync());
  });
})();
