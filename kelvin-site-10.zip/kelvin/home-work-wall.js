(() => {
  'use strict';

  function initHomeWorkWall() {
    const section = document.querySelector('.reference-site #work');
    if (!section || section.querySelector('[data-home-work-wall]')) return;
    const previous = section.querySelector('.framer-1gcxkgd-container');
    if (!previous) return;

    const pictures = {
      wukongStudent: {src: '/assets/portfolio/wukong-dodo/WechatIMG3561.jpg', width: 842, height: 1786, alt: '悟空哆哆家長與學生端：尋找合適的老師'},
      wukongTeacher: {src: '/assets/portfolio/wukong-dodo/WechatIMG3595.jpg', width: 854, height: 1752, alt: '悟空哆哆教師端：導師工作台'},
      knoutHome: {src: '/assets/portfolio/knout-latest/home.webp', width: 1140, height: 2616, alt: 'KnoutCounter Android 訓練首頁'},
      knoutLibrary: {src: '/assets/portfolio/knout-latest/exercise-library.webp', width: 1140, height: 2616, alt: 'KnoutCounter Android 動作資料庫'},
      course: {src: '/assets/courseware/course-home-hd.jpg', width: 3840, height: 2160, alt: '生化 AI 課件：課程首頁與六章導覽'},
      shadow: {src: '/assets/photography/photo-067.webp', width: 2400, height: 1425, alt: '階梯上的影子：格紋牆上的光斑、人物影子與斜向扶手'},
    };
    const works = [
      {title: '悟空哆哆', kind: '小程序 · 雙端介面', href: '/work/wukong/', name: 'wukong', images: [pictures.wukongStudent, pictures.wukongTeacher]},
      {title: 'MAOS', kind: '網站 · 滾動敘事', href: '/work/maos/', name: 'maos', ratio: 1920 / 1080, video: true},
      {title: 'KnoutCounter', kind: 'Android · 運動體驗', href: '/work/knoutcounter/', name: 'knout', images: [pictures.knoutHome, pictures.knoutLibrary]},
      {title: '生化 AI 課件', kind: '教學 · 互動圖解', href: '/teaching/', name: 'teaching', images: [pictures.course]},
      {title: 'AI 視覺系列', kind: '生成式視覺 · 作品整理中', name: 'ai', ratio: 1.2, placeholder: true},
      {title: '階梯上的影子', kind: '攝影 · Kelvin Choi', href: '/photography/#photo-067', name: 'photo', images: [pictures.shadow]},
    ];
    const wall = document.createElement('div');
    wall.className = 'hww-wall';
    wall.dataset.homeWorkWall = '';
    const videos = [];

    works.forEach((work, index) => {
      if (index % 3 === 0) {
        const row = document.createElement('div');
        row.className = 'hww-row';
        wall.append(row);
      }
      const ratio = work.ratio || work.images.reduce((total, picture) => total + picture.width / picture.height, 0);
      const card = document.createElement(work.placeholder ? 'div' : 'a');
      card.className = `hww-card hww-${work.name}`;
      if (!work.placeholder) card.href = work.href;
      card.style.setProperty('--hww-ratio', String(ratio));
      card.setAttribute('aria-label', work.placeholder ? 'AI 視覺系列：完整單圖封面，原圖尚待補充' : `查看${work.title}`);
      const art = document.createElement('span');
      art.className = `hww-art${work.images?.length === 2 ? ' hww-dual' : ''}`;

      if (work.video) {
        const video = document.createElement('video');
        video.muted = true;
        video.defaultMuted = true;
        video.loop = true;
        video.playsInline = true;
        video.setAttribute('muted', '');
        video.setAttribute('playsinline', '');
        video.preload = 'metadata';
        video.width = 1920;
        video.height = 1080;
        video.poster = '/assets/portfolio/maos/landing-poster.webp?v=20261025-2';
        video.setAttribute('aria-label', 'MAOS 網站首頁與滾動展示');
        const source = document.createElement('source');
        source.src = '/assets/portfolio/maos/landing-scroll.mp4?v=20261025-2';
        source.type = 'video/mp4';
        video.append(source);
        art.append(video);
        videos.push({video, inView: false});
      } else if (work.placeholder) {
        art.classList.add('hww-ai-single');
        const label = document.createElement('span');
        label.textContent = 'AI 視覺';
        const status = document.createElement('small');
        status.textContent = '作品整理中';
        art.append(label, status);
      } else {
        work.images.forEach(picture => {
          const image = document.createElement('img');
          image.src = picture.src;
          image.width = picture.width;
          image.height = picture.height;
          image.alt = picture.alt;
          image.loading = 'lazy';
          image.decoding = 'async';
          image.style.setProperty('--hww-image-ratio', String(picture.width / picture.height));
          if (work.name === 'photo') {
            image.srcset = '/assets/photography/photo-067-thumb.webp 900w, /assets/photography/photo-067.webp 2400w';
            image.sizes = '(max-width:640px) 100vw, 40vw';
          }
          art.append(image);
        });
      }

      const caption = document.createElement('span');
      caption.className = 'hww-caption';
      const title = document.createElement('span');
      title.className = 'hww-title';
      title.textContent = `${String(index + 1).padStart(2, '0')} · ${work.title}`;
      const kind = document.createElement('span');
      kind.className = 'hww-kind';
      kind.textContent = work.kind;
      caption.append(title, kind);
      card.append(art, caption);
      wall.lastElementChild.append(card);
    });

    // Remove the old fixed-height region and its hover-expansion targets.
    // This also keeps main.js's legacy initWork selector away from the new wall.
    previous.replaceWith(wall);
    const lead = [...section.querySelectorAll('p')].find(paragraph => paragraph.textContent.includes('項目成果、生成式影像與視覺實驗'));
    if (lead) lead.textContent = '產品、網站、互動課件與攝影選作。AI 視覺系列將在整理作品後補充。';

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const sync = state => {
      if (!state.inView || document.hidden || reducedMotion.matches) {
        state.video.pause();
        return;
      }
      if (state.video.paused) state.video.play().catch(() => {});
    };
    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          const state = videos.find(item => item.video === entry.target);
          if (!state) return;
          state.inView = entry.isIntersecting && entry.intersectionRatio >= .15;
          sync(state);
        });
      }, {threshold: [0, .15]});
      videos.forEach(state => observer.observe(state.video));
    }
    document.addEventListener('visibilitychange', () => videos.forEach(sync));
    window.addEventListener('pagehide', () => videos.forEach(state => state.video.pause()));
    window.addEventListener('pageshow', () => videos.forEach(sync));
    reducedMotion.addEventListener('change', () => videos.forEach(sync));
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initHomeWorkWall, {once: true});
  else initHomeWorkWall();
})();
