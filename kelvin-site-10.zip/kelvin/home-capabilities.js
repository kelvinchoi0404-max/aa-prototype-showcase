(() => {
  const root = document.querySelector('.home-capabilities');
  if (!root) return;
  const items = [
    ['產品與界面','界面細節','從使用者的需要出發，把功能整理成清楚、順手的界面。','/work/wukong/','查看悟空哆哆'],
    ['網站與應用','網站與動效','MAOS：以綠色首頁的滾動敘事，串起照護協作的產品概念。','/work/maos/','查看 MAOS'],
    ['AI 工具與流程','來源與引用','課元：從來源資料到題目引用，讓生成內容保留可追溯的依據。','/work/course-unit/','查看課元'],
    ['教學與內容','互動圖解','把抽象概念拆成圖解與操作步驟，讓內容成為可以探索的學習介面。','/teaching/','查看課件設計'],
    ['攝影與影像','光影觀察','留意日常的光與情緒，透過取景和編排留下自己的觀看方式。','/photography/','查看攝影作品'],
    ['生成式視覺','作品拼貼','生成式視覺作品整理中。','','']
  ];
  const buttons = [...root.querySelectorAll('[data-capability]')];
  const views = [...root.querySelectorAll('[data-capability-view]')];
  const video = root.querySelector('video');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  let current = 0;
  let visible = false;
  function syncMotion() {
    if (current === 1 && visible && !document.hidden && !reduced.matches) video.play().catch(() => {});
    else video.pause();
  }
  function select(index) {
    current = index;
    buttons.forEach((button,i) => button.setAttribute('aria-pressed', String(index === i)));
    views.forEach((view,i) => { view.hidden = index !== i; });
    const [name,kind,description,url,label] = items[index];
    root.querySelector('h3').textContent = name;
    root.querySelector('.home-capabilities-kind').textContent = kind;
    root.querySelector('.home-capabilities-footer p').textContent = description;
    const link = root.querySelector('.home-capabilities-footer a');
    link.hidden = !url;
    if (url) { link.href = url; link.textContent = label + ' ↗'; }
    syncMotion();
  }
  buttons.forEach((button,i) => button.addEventListener('click', () => select(i)));
  new IntersectionObserver(entries => { visible = entries[0].isIntersecting; syncMotion(); }, {threshold:.15}).observe(root);
  document.addEventListener('visibilitychange', syncMotion);
  reduced.addEventListener('change', syncMotion);
  select(0);
})();
