(() => {
  'use strict';
  const stage = document.querySelector('[data-teaching-motion]');
  const video = stage?.querySelector('video');
  const toggle = stage?.querySelector('[data-teaching-motion-toggle]');
  if (!video || !toggle) return;

  const label = toggle.querySelector('[data-teaching-motion-label]');
  const viewer = document.querySelector('.teaching-viewer');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let visible = false;
  let pageActive = true;
  let pausedByUser = false;
  let motionOptIn = false;
  let failed = false;

  video.muted = true;
  video.defaultMuted = true;
  toggle.hidden = false;

  function canPlay() {
    return visible && pageActive && !document.hidden && !viewer?.open && !failed &&
      !pausedByUser && (!reducedMotion.matches || motionOptIn);
  }

  function updateControl() {
    const playing = !video.paused && !video.ended;
    stage.classList.toggle('is-playing', playing);
    label.textContent = playing ? '暫停' : '播放';
    toggle.setAttribute('aria-label', playing ? '暫停矩陣變換演示' : '播放矩陣變換演示');
  }

  function syncPlayback() {
    // A deliberate play in reduced-motion mode lasts only while this view is active.
    if (!visible || !pageActive || document.hidden || viewer?.open) motionOptIn = false;
    if (reducedMotion.matches && !motionOptIn) stage.classList.add('is-poster');
    if (!canPlay()) {
      video.pause();
    } else if (video.paused) {
      video.play().then(() => {
        if (!canPlay()) video.pause();
        updateControl();
      }).catch(updateControl);
    }
    updateControl();
  }

  function checkVisibility() {
    const rect = stage.getBoundingClientRect();
    visible = rect.bottom > 0 && rect.top < window.innerHeight &&
      rect.right > 0 && rect.left < window.innerWidth;
    syncPlayback();
  }

  toggle.addEventListener('click', () => {
    if (video.paused) {
      pausedByUser = false;
      motionOptIn = true;
      checkVisibility();
    } else {
      pausedByUser = true;
      syncPlayback();
    }
  });
  video.addEventListener('playing', () => {
    if (canPlay()) stage.classList.remove('is-poster');
    else video.pause();
    updateControl();
  });
  video.addEventListener('pause', updateControl);
  const showPoster = () => {
    failed = true;
    stage.classList.add('is-poster');
    toggle.hidden = true;
    syncPlayback();
  };
  video.addEventListener('error', showPoster);
  video.querySelector('source')?.addEventListener('error', showPoster);
  document.addEventListener('visibilitychange', syncPlayback);
  window.addEventListener('pagehide', () => {
    pageActive = false;
    syncPlayback();
  });
  window.addEventListener('pageshow', () => {
    pageActive = true;
    checkVisibility();
  });
  reducedMotion.addEventListener('change', () => {
    motionOptIn = false;
    syncPlayback();
  });
  if (viewer) new MutationObserver(syncPlayback).observe(viewer, { attributes: true, attributeFilter: ['open'] });
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(entries => {
      visible = entries[0].isIntersecting && entries[0].intersectionRatio > 0;
      syncPlayback();
    }, { threshold: [0, .01] }).observe(stage);
  } else {
    window.addEventListener('scroll', checkVisibility, { passive: true });
    window.addEventListener('resize', checkVisibility, { passive: true });
  }
  checkVisibility();
})();

(() => {
  'use strict';
  const screens = [...document.querySelectorAll('[data-teaching-screen]')];
  const viewer = document.querySelector('.teaching-viewer');
  if (!screens.length || !viewer) return;
  const image = viewer.querySelector('.teaching-viewer-image img');
  const title = viewer.querySelector('#teaching-viewer-title');
  const count = viewer.querySelector('[data-teaching-count]');
  const close = viewer.querySelector('.teaching-viewer-close');
  const zoom = viewer.querySelector('[data-teaching-zoom]');
  const imageContainer = viewer.querySelector('.teaching-viewer-image');
  let current = 0;
  let trigger;
  let previousOverflow = '';
  function setZoom(enlarged) {
    viewer.classList.toggle('is-zoomed', enlarged);
    zoom.setAttribute('aria-pressed', String(enlarged));
    zoom.textContent = enlarged ? '適合畫面' : '放大細節';
    zoom.setAttribute('aria-label', enlarged ? '將完整介面縮放至適合畫面' : '放大介面細節，以原尺寸檢視');
    image.style.width = enlarged ? `${image.naturalWidth || 1280}px` : '';
    imageContainer.tabIndex = enlarged ? 0 : -1;
    imageContainer.scrollLeft = 0;
    imageContainer.scrollTop = 0;
  }
  function display(index) {
    setZoom(false);
    current = (index + screens.length) % screens.length;
    const screen = screens[current];
    const source = screen.querySelector('img');
    image.src = source.currentSrc || source.src;
    image.alt = source.alt;
    title.textContent = screen.dataset.screenTitle;
    count.textContent = `${String(current + 1).padStart(2, '0')} / ${String(screens.length).padStart(2, '0')}`;
  }
  screens.forEach((screen, index) => screen.addEventListener('click', () => {
    trigger = screen;
    display(index);
    previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    viewer.showModal();
    close.focus();
  }));
  close.addEventListener('click', () => viewer.close());
  zoom.addEventListener('click', () => setZoom(!viewer.classList.contains('is-zoomed')));
  viewer.querySelector('[data-teaching-prev]').addEventListener('click', () => display(current - 1));
  viewer.querySelector('[data-teaching-next]').addEventListener('click', () => display(current + 1));
  viewer.addEventListener('keydown', event => {
    if (viewer.classList.contains('is-zoomed') && event.target === imageContainer) return;
    if (event.key === 'ArrowRight') { event.preventDefault(); display(current + 1); }
    if (event.key === 'ArrowLeft') { event.preventDefault(); display(current - 1); }
  });
  viewer.addEventListener('close', () => {
    document.body.style.overflow = previousOverflow;
    trigger?.focus({ preventScroll: true });
  });
})();
