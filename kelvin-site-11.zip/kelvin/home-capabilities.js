/* Media follows the original service controller in main.js. */
(() => {
  function initCapabilityMotion() {
    const panel = document.querySelector('#services [data-services]');
    const video = panel?.querySelector('video');
    if (!video) return;
    const reduced = matchMedia('(prefers-reduced-motion: reduce)');
    let visible = false;
    const sync = () => {
      if (panel.dataset.serviceIndex === '1' && visible && !document.hidden && !reduced.matches) video.play().catch(() => {});
      else video.pause();
    };
    panel.addEventListener('servicechange', sync);
    new IntersectionObserver(entries => { visible = entries[0].isIntersecting; sync(); }, {threshold:.15}).observe(panel);
    document.addEventListener('visibilitychange', sync);
    reduced.addEventListener('change', sync);
    window.addEventListener('pagehide', () => video.pause());
    window.addEventListener('pageshow', sync);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initCapabilityMotion, {once:true});
  else initCapabilityMotion();
})();
