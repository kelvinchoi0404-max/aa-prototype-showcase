/* Mailto keeps the inquiry in the visitor's email client. */
(() => {
  'use strict';
  const email = 'kelvinchoi0404@gmail.com';
  const compose = document.getElementById('contact-compose');
  const status = document.querySelector('.contact-action-status');
  const fields = [
    ['需求', document.getElementById('brief-needs')],
    ['現有素材', document.getElementById('brief-materials')],
    ['預期時程', document.getElementById('brief-timing')]
  ];
  const updateMail = () => {
    if (!compose) return;
    const lines = ['Kelvin 你好，', '', '想和你聊聊一個合作想法：', ''];
    fields.forEach(([label, field]) => {
      const value = field?.value.trim();
      if (value) lines.push(label + '：', value, '');
    });
    compose.href = 'mailto:' + email + '?subject=' + encodeURIComponent('合作洽談') + '&body=' + encodeURIComponent(lines.join('\n'));
  };
  fields.forEach(([,field]) => field?.addEventListener('input',updateMail));
  updateMail();
  const copyContact = async (value, label) => {
    let copied = false;
    try {
      await navigator.clipboard.writeText(value);
      copied = true;
    } catch {
      const field = document.createElement('textarea');
      field.value = value;
      field.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.append(field);
      field.select();
      try { copied = document.execCommand('copy'); } catch { copied = false; }
      field.remove();
    }
    if (status) status.textContent = copied ? `已複製${label}。` : `可直接選取上方${label}複製。`;
  };
  document.querySelector('[data-copy-email]')?.addEventListener('click', () => copyContact(email, '電郵地址'));
  document.querySelector('[data-copy-wechat]')?.addEventListener('click', () => copyContact('kelvinchoi0404', '微信號'));
})();

/* This short page reveals the introduction once, independently of scroll distance. */
(() => {
  'use strict';
  const paragraphs = [...document.querySelectorAll('.contact-page [data-contact-reveal]')];
  if (!paragraphs.length) return;
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  let observer;
  let finished = false;
  const reveal = () => {
    if (finished) return;
    finished = true;
    paragraphs.forEach(paragraph => paragraph.classList.add('is-revealed'));
    observer?.disconnect();
  };
  paragraphs.forEach(paragraph => {
    const chars = [...paragraph.querySelectorAll(':scope > [aria-hidden="true"] > span')];
    chars.forEach((char, index) => {
      char.style.setProperty('--contact-char-delay', `${Math.round(index / Math.max(1, chars.length - 1) * 980)}ms`);
    });
  });
  if (reduced.matches || !('IntersectionObserver' in window)) {
    reveal();
    return;
  }
  paragraphs.forEach(paragraph => paragraph.classList.add('is-ready'));
  observer = new IntersectionObserver(entries => {
    if (entries.some(entry => entry.isIntersecting && entry.intersectionRatio >= 0.2)) reveal();
  }, { threshold: 0.2, rootMargin: '0px 0px -6% 0px' });
  paragraphs.forEach(paragraph => observer.observe(paragraph));
  reduced.addEventListener('change', event => { if (event.matches) reveal(); });
})();
